# PANGANAY: a Unity story game

A short **visual novel** with a budgeting mini-game, about Mark Santos, a 19-year-old working student in a low-middle-income Filipino family. Over 7 weeks you split his pay across the household's needs, make story choices, and face a family emergency. It leads into a conversation about family planning, responsible parenthood and financial preparation.

**There is no scene to set up.** The scripts create the entire UI at runtime and start themselves.

## Features

* **Backlog (LOG):** Scroll back through everything said so far, including the choices you made.
* **AUTO:** Lines advance on their own after you have had time to read them. It stops at choices.
* **SKIP:** Fast-forwards lines you have already read, even from earlier playthroughs. It stops at new text.
* **Save / Load:** 3 manual slots plus an **autosave at the start of every week**. A Load button appears on the title screen once a save exists. Saves are stored with `PlayerPrefs`, so they also work in WebGL builds.
* **Sound:** Background music that crossfades per scene, typing blips, click and stat sounds, and a SOUND/MUTED toggle. Simple built-in tones are used until you add your own files.
* **Transitions:** Backgrounds crossfade, weeks fade in from black, characters slide and fade in, and the speaker is highlighted.

## How it plays

* Full-screen background, standing characters, a dialogue box with a name tag, and typewriter text.
* **Click** or press **Space / Enter** to advance. The first click finishes the line, the next goes on.
* Choices appear in the middle of the screen. Stat changes pop up above the dialogue box.
* The weekly **budget** is a separate screen. The title and chapter cards are full-screen captions.

## Run it in 3 steps

1. In Unity Hub, create a new project from the **2D** or **Universal 2D** template. Unity 2021.3 LTS or newer works, including Unity 6.
2. Copy the `Assets/Scripts` folder from this package into your project's `Assets` folder.
3. Open any scene (the default `SampleScene` is fine) and press **Play**.

Set the Game view to **Full HD (1920x1080)** or **Free Aspect**. The UI scales to any 16:9-ish window.

## Build for the web (so friends can play in a browser)

1. In Unity Hub, install the **WebGL Build Support** module for your editor version.
2. **File > Build Profiles** (or **Build Settings**) > **WebGL** > **Build**.
3. Zip the output folder and upload it to itch.io (kind of project: HTML, tick "This file will be played in the browser").

## How the game works

| Part | Description |
|---|---|
| Stats | **Savings**, **Energy**, **Grades**, **Family** (bond) and **Planning** (how much the family has learned to plan together). |
| Weekly flow | Story scenes, then choices, then a **budget screen** (pay or skip each need), then an evening choice (study, overtime, rest, family). |
| Budget | Pay is ₱1,500 a week. Needs cost slightly more than that, so you draw down savings or skip things. Skipped needs have consequences. |
| Emergency | Week 4: Baby Joy gets sick. Your earlier savings and your choice (social worker/PhilHealth, a salary advance, or a "5-6" loan) matter. |
| Conversation | Week 5: how you talk to your parents changes how they react. |
| Health center | Week 6: a respectful, factual family planning counseling scene. Mark supports; his parents decide. |
| Endings | 5 endings: *A Plan, Together*, *First Steps*, *Carrying It Alone*, *Walls Between Us*, *Running on Empty*. |

In a simulation of 5,000 random playthroughs, all five endings were reachable, and a thoughtful player reaches the best ending.

## Adding art (no code needed)

Drop images into these folders and the game picks them up automatically. Each folder has a `README.txt` with the exact file names.

* `Assets/Resources/Characters/` holds standing sprites (PNG with a transparent background) named after the speaker, e.g. `Mark.png` or `Mama Liza.png`. Mark stands on the left. Whoever else is talking stands on the right. The speaker is bright and the other is dimmed.
* `Assets/Resources/Backgrounds/` holds `title`, `house_morning`, `house_night`, `restaurant`, `school`, `hospital`, `kitchen_night`, `health_center`, `family_table` and `ending`.

Anything missing falls back to a colored silhouette and a plain dark background, so you can add art one piece at a time.

## Adding sound (no code needed)

Drop files into `Assets/Resources/Audio/Music/` and `Assets/Resources/Audio/Sfx/`. Each folder has a `README.txt` listing the exact names (for example `home.mp3`, `tense.ogg`, `click.wav`). Missing music means silence. Missing sound effects fall back to built-in tones.

## Customizing

Everything is in plain C#:

* **`Content.cs`** holds all the story (use `.Bg("name")` on a step to change the background), dialogue, prices, choices, effects and endings. Add a week by adding another `Chapter` in `Build()`. Add a choice by adding a `Pick(...)`.
* **`GameModels.cs`** holds the data types and the `GameState` rules (stat limits, debt).
* **`GameController.cs`** builds the UI (colors are at the top of the file) and runs the flow.

Ideas for next steps:

* **Expressions:** Add `Characters/<Name>_<mood>.png` and a mood field on `Step`.
* **Language:** Add a Filipino/English toggle by making each string a pair, or load strings from a JSON file.
* **Save/Load:** Store `GameState` with `PlayerPrefs` or JSON.
* **Settings menu:** Text speed (`CharsPerSecond`) and music/sfx volume sliders (`MusicVolume`, `SfxVolume`), both constants at the top of `GameController.cs`.
* **More scenes:** Mark's relationship with his professor, a mid-game minigame (e.g. a jeepney commute), more siblings' stories.

## Troubleshooting

* **The peso sign shows as a box:** The game checks for it and falls back to `Php`. To force it, set `cur = "Php "` in `GameController.cs`.
* **Buttons don't respond:** The game adds an EventSystem automatically and supports both the old and new Input System. If you use a custom EventSystem, make sure it exists in the scene.
* **Text overflows the card on a very small window:** Reduce the font sizes in `PresentPanel(...)` calls, or increase the card height in `BuildCard()`.
* **A "No cameras rendering" message in Game view:** Add a Camera to the scene (the default scene already has one).

## About the content

The story is fiction, written to start conversations about planning, communication and money in a family. The health center scene deliberately stays factual and non-judgmental: it states that family planning decisions belong to the couple, that counseling is confidential, and that a health worker screens for suitable methods. Please have a local health worker or teacher review any version you share publicly.
