using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem.UI;
#endif

namespace Panganay
{
    [Serializable]
    public class SaveData
    {
        public int version = 1;
        public int money, energy, grades, family, planning, debt;
        public string[] flags;
        public int ci, si;
        public string bg, music, label, stamp;
    }

    /// <summary>
    /// Visual-novel front end. Builds the whole UI in code and runs the story.
    /// Nothing to set up: it starts itself when you press Play in ANY scene.
    ///
    /// Layers (back to front): background (+crossfade), dim, characters, click catcher,
    /// dialogue box + quick menu, choices, caption cards, budget panel, HUD,
    /// fade-to-black, backlog, save/load slots.
    /// </summary>
    public class GameController : MonoBehaviour
    {
        static GameController instance;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Boot()
        {
            if (instance != null) return;
            var go = new GameObject("PanganayGame");
            instance = go.AddComponent<GameController>();
        }

        // ---------- tuning ----------
        const float CharsPerSecond = 55f;     // typewriter speed
        const float MusicVolume = 0.55f;
        const float SfxVolume = 0.8f;
        const float MusicFade = 1.2f;         // seconds
        const int SlotCount = 3;              // manual slots (slot 0 is the autosave)
        const int MaxLog = 300;

        // ---------- palette ----------
        static readonly Color BgColor = new Color(0.07f, 0.09f, 0.14f);
        static readonly Color HeaderColor = new Color(0.05f, 0.06f, 0.10f, 0.92f);
        static readonly Color CardColor = new Color(0.10f, 0.12f, 0.19f, 0.97f);
        static readonly Color BoxColor = new Color(0.04f, 0.05f, 0.09f, 0.90f);
        static readonly Color Amber = new Color(0.98f, 0.76f, 0.28f);
        static readonly Color TextColor = new Color(0.94f, 0.95f, 0.97f);
        static readonly Color NarrationColor = new Color(0.80f, 0.85f, 0.93f);
        static readonly Color Muted = new Color(0.62f, 0.67f, 0.76f);
        static readonly Color BtnColor = new Color(0.30f, 0.38f, 0.55f);
        static readonly Color BtnOn = new Color(0.22f, 0.50f, 0.52f);
        static readonly Color BtnOff = new Color(0.27f, 0.29f, 0.36f);
        static readonly Color BtnGo = new Color(0.86f, 0.62f, 0.18f);
        static readonly Color QuickColor = new Color(0.18f, 0.22f, 0.32f, 0.92f);
        static readonly Color Bad = new Color(1.00f, 0.45f, 0.42f);

        class StatBar
        {
            public Text value;
            public RectTransform fill;
            public Image fillImg;
            public float shown, target;
            public Color color;
        }

        class CharView
        {
            public RectTransform rt;
            public Image img;
            public Text label;
            public CanvasGroup group;
            public string name;
            public bool hasArt;
            public float side;                 // -1 slides in from the left, +1 from the right
            public float curA, tgtA, curX, tgtX, curS = 1f, tgtS = 1f;
        }

        class LogEntry { public string speaker; public string text; }

        // ---------- game ----------
        GameState s;
        List<Chapter> chapters;
        int ci, si;
        int resumeIndex;          // step to re-show if the game is loaded from here
        string cur = "₱";
        string currentBg, currentMusic;

        // budget screen state
        Step budgetStep;
        bool[] paid;

        // dialogue state
        Action pending;           // what happens when the player advances
        bool typing;
        string typeFull;
        bool blipOn, currentSeen;
        string rightName;         // last non-Mark speaker in this chapter
        readonly List<LogEntry> log = new List<LogEntry>();
        readonly HashSet<int> seen = new HashSet<int>();
        bool autoOn, skipOn, modalOpen, muted;
        float autoTimer, skipTimer;

        // ---------- UI ----------
        Font font;
        Sprite roundSprite, circleSprite;
        Image bgImage, bgFade, dim, fadeOverlay;
        CharView leftChar, rightChar;
        Button catcher;
        RectTransform vnLayer, choicesArea, captionLayer, captionButtons;
        CanvasGroup captionGroup;
        Image nameTag;
        Text nameText, vnText, indicator, toast, captionText;
        Button autoBtn, skipBtn, soundBtn;
        Text soundBtnText;
        RectTransform card, bodyRT, buttonArea;
        CanvasGroup cardGroup;
        Text panelText, headerTitle, headerSub, moneyLabel, moneyValue;
        StatBar energyBar, gradesBar, familyBar, planBar;
        RectTransform logLayer, slotLayer, slotList;
        Text logText, slotTitle;
        ScrollRect logScroll;
        readonly Dictionary<string, Color> speakerColors = new Dictionary<string, Color>();

        // ---------- coroutines ----------
        Coroutine typeCo, toastCo, fadeCo, bgFadeCo, blackCo, captionCo, musicCo, scrollCo;

        // ---------- audio ----------
        AudioSource musicA, musicB, sfxSource, blipSource;
        bool musicAActive;
        readonly Dictionary<string, AudioClip> sfxCache = new Dictionary<string, AudioClip>();

        void Awake()
        {
            DontDestroyOnLoad(gameObject);
            font = LoadFont();
            CheckPesoGlyph();
            roundSprite = MakeRoundedSprite(64, 20);
            circleSprite = MakeRoundedSprite(128, 64);
            SetupSpeakerColors();
            EnsureEventSystem();
            SetupAudio();
            LoadSeen();
            BuildUI();
            ShowTitle();
        }

        void OnApplicationQuit() { SaveSeen(); }

        void Update()
        {
            float dt = Time.unscaledDeltaTime;
            AnimateBar(energyBar); AnimateBar(gradesBar); AnimateBar(familyBar); AnimateBar(planBar);
            AnimateChar(leftChar, dt); AnimateChar(rightChar, dt);

            bool vnActive = vnLayer.gameObject.activeSelf && !modalOpen;

            if (pending != null && vnActive && AdvancePressed())
                OnAdvance();

            // Skip: fast-forwards lines the player has already read. Stops at unread text.
            if (skipOn && vnActive && pending != null)
            {
                if (!currentSeen) SetSkip(false);
                else
                {
                    skipTimer += dt;
                    if (skipTimer >= 0.05f) { skipTimer = 0f; OnAdvance(); }
                }
            }
            // Auto: advances after the line has been read.
            else if (autoOn && vnActive && pending != null && !typing)
            {
                autoTimer += dt;
                if (autoTimer >= 1.0f + 0.035f * VisibleLength(typeFull)) { autoTimer = 0f; OnAdvance(); }
            }

            if (indicator != null && indicator.gameObject.activeSelf)
            {
                float a = 0.55f + 0.45f * Mathf.Sin(Time.unscaledTime * 5f);
                indicator.color = new Color(1f, 1f, 1f, a);
            }
        }

        static bool AdvancePressed()
        {
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
            var k = UnityEngine.InputSystem.Keyboard.current;
            return k != null && (k.spaceKey.wasPressedThisFrame || k.enterKey.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return);
#endif
        }

        // =====================================================================
        //  SETUP HELPERS
        // =====================================================================
        Font LoadFont()
        {
            Font f = null;
            try
            {
#if UNITY_2022_2_OR_NEWER
                f = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
                f = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
            }
            catch (Exception) { }
            if (f == null) f = Font.CreateDynamicFontFromOSFont("Arial", 32);
            return f;
        }

        void CheckPesoGlyph()
        {
            // If the font has no peso sign, fall back to "Php ".
            try
            {
                font.RequestCharactersInTexture("₱", 32);
                if (!font.HasCharacter('₱')) cur = "Php ";
            }
            catch (Exception) { cur = "Php "; }
        }

        void EnsureEventSystem()
        {
            if (EventSystem.current != null) return;
            var go = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
            var module = go.AddComponent<InputSystemUIInputModule>();
            module.AssignDefaultActions();
#else
            go.AddComponent<StandaloneInputModule>();
#endif
            go.transform.SetParent(transform, false);
        }

        void SetupSpeakerColors()
        {
            speakerColors[Content.Mark] = new Color(0.30f, 0.70f, 0.75f);
            speakerColors[Content.Mama] = new Color(0.90f, 0.50f, 0.65f);
            speakerColors[Content.Tatay] = new Color(0.90f, 0.62f, 0.30f);
            speakerColors[Content.Bea] = new Color(0.65f, 0.55f, 0.90f);
            speakerColors[Content.Jun] = new Color(0.45f, 0.65f, 0.95f);
            speakerColors[Content.Lyn] = new Color(0.95f, 0.75f, 0.35f);
            speakerColors[Content.Midwife] = new Color(0.45f, 0.78f, 0.50f);
            speakerColors[Content.Boss] = new Color(0.75f, 0.55f, 0.45f);
            speakerColors[Content.Prof] = new Color(0.60f, 0.65f, 0.75f);
        }

        Color SpeakerColor(string name)
        {
            Color c;
            return speakerColors.TryGetValue(name, out c) ? c : Muted;
        }

        static Sprite MakeRoundedSprite(int size, int radius)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Bilinear;
            tex.wrapMode = TextureWrapMode.Clamp;
            var px = new Color[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float cx = Mathf.Clamp(x + 0.5f, radius, size - radius);
                    float cy = Mathf.Clamp(y + 0.5f, radius, size - radius);
                    float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(cx, cy));
                    float a = Mathf.Clamp01(radius - d + 0.5f);
                    px[y * size + x] = new Color(1f, 1f, 1f, a);
                }
            }
            tex.SetPixels(px);
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0,
                                 SpriteMeshType.FullRect, new Vector4(radius, radius, radius, radius));
        }

        // ---------- optional art (PNG/JPG in Assets/Resources) ----------
        Sprite LoadSprite(string path)
        {
            var sp = Resources.Load<Sprite>(path);
            if (sp != null) return sp;
            // Works even if the image was not imported as "Sprite (2D and UI)".
            var tex = Resources.Load<Texture2D>(path);
            if (tex == null) return null;
            return Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 100f);
        }

        /// <summary>Changes the background with a crossfade.</summary>
        void SetBackground(string name)
        {
            if (string.IsNullOrEmpty(name) || name == currentBg) return;
            var sp = LoadSprite("Backgrounds/" + name);
            // old picture goes on top and fades out
            bgFade.sprite = bgImage.sprite;
            bgFade.color = bgImage.color;
            bgFade.gameObject.SetActive(true);
            bgImage.sprite = sp;
            bgImage.color = sp != null ? Color.white : BgColor;
            currentBg = name;
            if (bgFadeCo != null) StopCoroutine(bgFadeCo);
            bgFadeCo = StartCoroutine(BgFadeRoutine());
        }

        IEnumerator BgFadeRoutine()
        {
            Color c = bgFade.color;
            float t = 0f;
            while (t < 0.7f)
            {
                t += Time.unscaledDeltaTime;
                bgFade.color = new Color(c.r, c.g, c.b, c.a * (1f - Mathf.Clamp01(t / 0.7f)));
                yield return null;
            }
            bgFade.gameObject.SetActive(false);
            bgFadeCo = null;
        }

        // =====================================================================
        //  AUDIO
        // =====================================================================
        void SetupAudio()
        {
            musicA = gameObject.AddComponent<AudioSource>();
            musicB = gameObject.AddComponent<AudioSource>();
            sfxSource = gameObject.AddComponent<AudioSource>();
            blipSource = gameObject.AddComponent<AudioSource>();
            musicA.loop = musicB.loop = true;
            musicA.playOnAwake = musicB.playOnAwake = false;
            sfxSource.playOnAwake = blipSource.playOnAwake = false;
            musicA.volume = musicB.volume = 0f;

            // Make sure something can hear the game (the default scene camera already has a listener).
#if UNITY_2023_1_OR_NEWER
            if (FindFirstObjectByType<AudioListener>() == null) gameObject.AddComponent<AudioListener>();
#else
            if (FindObjectOfType<AudioListener>() == null) gameObject.AddComponent<AudioListener>();
#endif
            muted = PlayerPrefs.GetInt("panganay_muted", 0) == 1;
            AudioListener.volume = muted ? 0f : 1f;
        }

        void PlayMusic(string name)
        {
            if (name == currentMusic) return;
            currentMusic = name;
            AudioClip clip = string.IsNullOrEmpty(name) ? null : Resources.Load<AudioClip>("Audio/Music/" + name);
            if (musicCo != null) StopCoroutine(musicCo);
            musicCo = StartCoroutine(CrossfadeMusic(clip));
        }

        IEnumerator CrossfadeMusic(AudioClip clip)
        {
            AudioSource from = musicAActive ? musicA : musicB;
            AudioSource to = musicAActive ? musicB : musicA;
            musicAActive = !musicAActive;
            if (clip != null)
            {
                to.clip = clip; to.loop = true; to.volume = 0f; to.Play();
            }
            float fromStart = from.volume;
            float t = 0f;
            while (t < MusicFade)
            {
                t += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(t / MusicFade);
                from.volume = fromStart * (1f - k);
                if (clip != null) to.volume = MusicVolume * k;
                yield return null;
            }
            from.Stop();
            if (clip == null) to.Stop();
            musicCo = null;
        }

        AudioClip Sfx(string name)
        {
            AudioClip c;
            if (sfxCache.TryGetValue(name, out c)) return c;
            c = Resources.Load<AudioClip>("Audio/Sfx/" + name);   // your own sound, if present
            if (c == null) c = DefaultSfx(name);                  // otherwise a simple built-in tone
            sfxCache[name] = c;
            return c;
        }

        AudioClip DefaultSfx(string name)
        {
            switch (name)
            {
                case "click": return Tone(name, new float[] { 1250f }, 0.06f, 0.35f);
                case "blip": return Tone(name, new float[] { 620f }, 0.03f, 0.30f);
                case "gain": return Tone(name, new float[] { 660f, 880f }, 0.09f, 0.35f);
                case "loss": return Tone(name, new float[] { 330f, 247f }, 0.12f, 0.35f);
                case "chapter": return Tone(name, new float[] { 523f, 659f, 784f }, 0.16f, 0.30f);
                case "save": return Tone(name, new float[] { 784f, 988f }, 0.10f, 0.30f);
                default: return null;
            }
        }

        static AudioClip Tone(string name, float[] freqs, float segSec, float vol)
        {
            int rate = 44100;
            int segN = (int)(rate * segSec);
            var data = new float[segN * freqs.Length];
            for (int k = 0; k < freqs.Length; k++)
            {
                for (int i = 0; i < segN; i++)
                {
                    float t = (float)i / rate;
                    float attack = Mathf.Min(1f, i / (rate * 0.004f));
                    float decay = Mathf.Pow(1f - (float)i / segN, 2f);
                    data[k * segN + i] = Mathf.Sin(2f * Mathf.PI * freqs[k] * t) * attack * decay * vol;
                }
            }
            var clip = AudioClip.Create(name, data.Length, 1, rate, false);
            clip.SetData(data, 0);
            return clip;
        }

        void PlaySfx(string name, float vol = 1f)
        {
            var c = Sfx(name);
            if (c != null) sfxSource.PlayOneShot(c, SfxVolume * vol);
        }

        void Blip()
        {
            var c = Sfx("blip");
            if (c == null) return;
            blipSource.pitch = UnityEngine.Random.Range(0.92f, 1.08f);
            blipSource.PlayOneShot(c, 0.35f * SfxVolume);
        }

        void ToggleSound()
        {
            muted = !muted;
            AudioListener.volume = muted ? 0f : 1f;
            PlayerPrefs.SetInt("panganay_muted", muted ? 1 : 0);
            UpdateQuickButtons();
            PlaySfx("click");
        }

        // =====================================================================
        //  UI BUILDING BLOCKS
        // =====================================================================
        RectTransform NewRect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            return go.GetComponent<RectTransform>();
        }

        static void Anchor(RectTransform r, float minX, float minY, float maxX, float maxY)
        {
            r.anchorMin = new Vector2(minX, minY);
            r.anchorMax = new Vector2(maxX, maxY);
            r.offsetMin = Vector2.zero;
            r.offsetMax = Vector2.zero;
        }

        Image NewImage(string name, Transform parent, Color c, Sprite sprite = null)
        {
            var rt = NewRect(name, parent);
            var img = rt.gameObject.AddComponent<Image>();
            img.color = c;
            img.raycastTarget = false;
            if (sprite != null) { img.sprite = sprite; img.type = Image.Type.Sliced; }
            return img;
        }

        Text NewText(string name, Transform parent, int size, Color c, TextAnchor anchor, FontStyle style = FontStyle.Normal)
        {
            var rt = NewRect(name, parent);
            var t = rt.gameObject.AddComponent<Text>();
            t.font = font;
            t.fontSize = size;
            t.color = c;
            t.alignment = anchor;
            t.fontStyle = style;
            t.supportRichText = true;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            t.lineSpacing = 1.15f;
            return t;
        }

        void AddShadow(Text t)
        {
            var sh = t.gameObject.AddComponent<Shadow>();
            sh.effectColor = new Color(0f, 0f, 0f, 0.85f);
            sh.effectDistance = new Vector2(2f, -2f);
        }

        void BuildUI()
        {
            var canvasGo = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasGo.transform.SetParent(transform, false);
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            var root = canvasGo.transform;

            bgImage = NewImage("Background", root, BgColor);
            Anchor(bgImage.rectTransform, 0, 0, 1, 1);
            bgFade = NewImage("BackgroundFade", root, new Color(0, 0, 0, 0));
            Anchor(bgFade.rectTransform, 0, 0, 1, 1);
            bgFade.gameObject.SetActive(false);
            dim = NewImage("Dim", root, new Color(0f, 0f, 0f, 0.2f));
            Anchor(dim.rectTransform, 0, 0, 1, 1);

            leftChar = MakeChar(root, "CharLeft", 0.05f, 0.27f, -1f);
            rightChar = MakeChar(root, "CharRight", 0.73f, 0.95f, 1f);

            BuildCatcher(root);
            BuildDialogue(root);
            BuildChoices(root);
            BuildCaption(root);
            BuildCard(root);
            BuildHeader(root);

            fadeOverlay = NewImage("FadeToBlack", root, new Color(0, 0, 0, 0));
            Anchor(fadeOverlay.rectTransform, 0, 0, 1, 1);

            BuildLog(root);
            BuildSlots(root);
        }

        CharView MakeChar(Transform root, string name, float x0, float x1, float side)
        {
            var rt = NewRect(name, root);
            rt.anchorMin = new Vector2(x0, 0.19f);
            rt.anchorMax = new Vector2(x1, 0.90f);
            rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
            var img = rt.gameObject.AddComponent<Image>();
            img.raycastTarget = false;
            var group = rt.gameObject.AddComponent<CanvasGroup>();
            group.blocksRaycasts = false;
            var label = NewText("Label", rt, 40, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold);
            Anchor(label.rectTransform, 0, 0, 1, 1);
            AddShadow(label);
            rt.gameObject.SetActive(false);
            return new CharView { rt = rt, img = img, label = label, group = group, side = side };
        }

        void BuildCatcher(Transform root)
        {
            var img = NewImage("Catcher", root, new Color(0, 0, 0, 0));
            img.raycastTarget = true;
            Anchor(img.rectTransform, 0, 0, 1, 1);
            catcher = img.gameObject.AddComponent<Button>();
            catcher.targetGraphic = img;
            catcher.transition = Selectable.Transition.None;
            var nav = new Navigation(); nav.mode = Navigation.Mode.None;
            catcher.navigation = nav;
            catcher.onClick.AddListener(() => OnAdvance());
        }

        void BuildDialogue(Transform root)
        {
            vnLayer = NewRect("Dialogue", root);
            Anchor(vnLayer, 0, 0, 1, 1);

            var box = NewImage("Box", vnLayer, BoxColor, roundSprite);
            var br = box.rectTransform;
            br.anchorMin = new Vector2(0.04f, 0.075f); br.anchorMax = new Vector2(0.96f, 0.33f);
            br.offsetMin = Vector2.zero; br.offsetMax = Vector2.zero;

            // Name tag straddling the top-left edge of the box
            nameTag = NewImage("NameTag", br, Amber, roundSprite);
            var nr = nameTag.rectTransform;
            nr.anchorMin = new Vector2(0, 1); nr.anchorMax = new Vector2(0, 1); nr.pivot = new Vector2(0, 0);
            nr.sizeDelta = new Vector2(400, 66); nr.anchoredPosition = new Vector2(48, -14);
            nameText = NewText("Name", nr, 34, Color.white, TextAnchor.MiddleCenter, FontStyle.Bold);
            Anchor(nameText.rectTransform, 0, 0, 1, 1);
            AddShadow(nameText);

            vnText = NewText("Text", br, 34, TextColor, TextAnchor.UpperLeft);
            Anchor(vnText.rectTransform, 0, 0, 1, 1);
            vnText.rectTransform.offsetMin = new Vector2(70, 30);
            vnText.rectTransform.offsetMax = new Vector2(-70, -48);

            indicator = NewText("Indicator", br, 34, Color.white, TextAnchor.LowerRight, FontStyle.Bold);
            indicator.text = "v";
            var ir = indicator.rectTransform;
            ir.anchorMin = new Vector2(1, 0); ir.anchorMax = new Vector2(1, 0); ir.pivot = new Vector2(1, 0);
            ir.sizeDelta = new Vector2(60, 50); ir.anchoredPosition = new Vector2(-34, 14);
            indicator.gameObject.SetActive(false);

            // Floating "+5 Energy" notices above the box
            toast = NewText("Toast", vnLayer, 32, TextColor, TextAnchor.LowerRight, FontStyle.Bold);
            var tr = toast.rectTransform;
            tr.anchorMin = new Vector2(0.96f, 0.33f); tr.anchorMax = new Vector2(0.96f, 0.33f); tr.pivot = new Vector2(1, 0);
            tr.sizeDelta = new Vector2(1300, 60); tr.anchoredPosition = new Vector2(0, 24);
            AddShadow(toast);
            toast.gameObject.SetActive(false);

            BuildQuickMenu(vnLayer);
        }

        void BuildQuickMenu(Transform parent)
        {
            var rt = NewRect("QuickMenu", parent);
            rt.anchorMin = new Vector2(0.96f, 0.012f); rt.anchorMax = new Vector2(0.96f, 0.012f);
            rt.pivot = new Vector2(1, 0);
            rt.sizeDelta = new Vector2(920, 54);
            var hlg = rt.gameObject.AddComponent<HorizontalLayoutGroup>();
            hlg.spacing = 10;
            hlg.childAlignment = TextAnchor.MiddleRight;
            hlg.childControlWidth = true; hlg.childControlHeight = true;
            hlg.childForceExpandWidth = true; hlg.childForceExpandHeight = true;

            QuickButton(rt, "LOG", OpenLog);
            autoBtn = QuickButton(rt, "AUTO", () => SetAuto(!autoOn));
            skipBtn = QuickButton(rt, "SKIP", () => SetSkip(!skipOn));
            QuickButton(rt, "SAVE", () => OpenSlots(true));
            QuickButton(rt, "LOAD", () => OpenSlots(false));
            soundBtn = QuickButton(rt, "SOUND", ToggleSound);
            soundBtnText = soundBtn.GetComponentInChildren<Text>();
            UpdateQuickButtons();
        }

        Button QuickButton(Transform parent, string label, Action action)
        {
            var b = AddButton(parent, label, action, QuickColor, 54f, true, 22);
            var t = b.GetComponentInChildren<Text>();
            t.alignment = TextAnchor.MiddleCenter;
            t.fontStyle = FontStyle.Bold;
            var le = b.GetComponent<LayoutElement>();
            le.flexibleWidth = 1f;
            return b;
        }

        void UpdateQuickButtons()
        {
            if (autoBtn != null) autoBtn.GetComponent<Image>().color = autoOn ? BtnOn : QuickColor;
            if (skipBtn != null) skipBtn.GetComponent<Image>().color = skipOn ? BtnOn : QuickColor;
            if (soundBtn != null)
            {
                soundBtn.GetComponent<Image>().color = muted ? BtnOff : QuickColor;
                soundBtnText.text = muted ? "MUTED" : "SOUND";
            }
        }

        void SetAuto(bool on)
        {
            autoOn = on; if (on) skipOn = false;
            autoTimer = 0f;
            UpdateQuickButtons();
            PlaySfx("click");
        }

        void SetSkip(bool on)
        {
            skipOn = on; if (on) autoOn = false;
            skipTimer = 0f;
            UpdateQuickButtons();
            if (on) PlaySfx("click");
        }

        void BuildChoices(Transform root)
        {
            choicesArea = NewRect("Choices", root);
            choicesArea.anchorMin = new Vector2(0.5f, 0.64f); choicesArea.anchorMax = new Vector2(0.5f, 0.64f);
            choicesArea.pivot = new Vector2(0.5f, 0.5f);
            choicesArea.sizeDelta = new Vector2(1300, 400);
            var vlg = choicesArea.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 14;
            vlg.childAlignment = TextAnchor.MiddleCenter;
            vlg.childControlWidth = true; vlg.childControlHeight = true;
            vlg.childForceExpandWidth = true; vlg.childForceExpandHeight = false;
        }

        void BuildCaption(Transform root)
        {
            captionLayer = NewRect("Caption", root);
            Anchor(captionLayer, 0, 0, 1, 1);
            captionGroup = captionLayer.gameObject.AddComponent<CanvasGroup>();
            captionText = NewText("Text", captionLayer, 44, TextColor, TextAnchor.MiddleCenter);
            captionText.rectTransform.anchorMin = new Vector2(0.08f, 0.40f);
            captionText.rectTransform.anchorMax = new Vector2(0.92f, 0.86f);
            captionText.rectTransform.offsetMin = Vector2.zero; captionText.rectTransform.offsetMax = Vector2.zero;
            AddShadow(captionText);

            captionButtons = NewRect("Buttons", captionLayer);
            captionButtons.anchorMin = new Vector2(0.5f, 0.22f); captionButtons.anchorMax = new Vector2(0.5f, 0.22f);
            captionButtons.pivot = new Vector2(0.5f, 0.5f);
            captionButtons.sizeDelta = new Vector2(520, 100);
            var vlg = captionButtons.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 14;
            vlg.childAlignment = TextAnchor.MiddleCenter;
            vlg.childControlWidth = true; vlg.childControlHeight = true;
            vlg.childForceExpandWidth = true; vlg.childForceExpandHeight = false;
        }

        void BuildHeader(Transform root)
        {
            var header = NewImage("Header", root, HeaderColor);
            var hr = header.rectTransform;
            hr.anchorMin = new Vector2(0, 1); hr.anchorMax = new Vector2(1, 1);
            hr.pivot = new Vector2(0.5f, 1);
            hr.sizeDelta = new Vector2(0, 120);
            hr.anchoredPosition = Vector2.zero;

            headerTitle = NewText("Week", hr, 38, Amber, TextAnchor.MiddleLeft, FontStyle.Bold);
            var tr = headerTitle.rectTransform;
            tr.anchorMin = new Vector2(0, 0.45f); tr.anchorMax = new Vector2(0.28f, 1);
            tr.offsetMin = new Vector2(40, 0); tr.offsetMax = Vector2.zero;
            headerSub = NewText("WeekSub", hr, 24, Muted, TextAnchor.UpperLeft);
            var sr = headerSub.rectTransform;
            sr.anchorMin = new Vector2(0, 0); sr.anchorMax = new Vector2(0.28f, 0.5f);
            sr.offsetMin = new Vector2(40, 0); sr.offsetMax = Vector2.zero;

            var stats = NewRect("Stats", hr);
            stats.anchorMin = new Vector2(0.28f, 0); stats.anchorMax = new Vector2(1, 1);
            stats.offsetMin = new Vector2(0, 10); stats.offsetMax = new Vector2(-30, -10);
            var hlg = stats.gameObject.AddComponent<HorizontalLayoutGroup>();
            hlg.spacing = 24;
            hlg.padding = new RectOffset(10, 10, 6, 6);
            hlg.childForceExpandWidth = true; hlg.childForceExpandHeight = true;
            hlg.childControlWidth = true; hlg.childControlHeight = true;

            MakeMoneyWidget(stats);
            energyBar = MakeStat(stats, "ENERGY", new Color(0.98f, 0.82f, 0.30f));
            gradesBar = MakeStat(stats, "GRADES", new Color(0.45f, 0.70f, 0.98f));
            familyBar = MakeStat(stats, "FAMILY", new Color(0.95f, 0.50f, 0.65f));
            planBar = MakeStat(stats, "PLANNING", new Color(0.50f, 0.85f, 0.60f));
        }

        void MakeMoneyWidget(Transform parent)
        {
            var w = NewRect("Savings", parent);
            var le = w.gameObject.AddComponent<LayoutElement>();
            le.flexibleWidth = 1.3f; le.minWidth = 190;
            moneyLabel = NewText("Label", w, 20, Muted, TextAnchor.UpperLeft, FontStyle.Bold);
            Anchor(moneyLabel.rectTransform, 0, 0.62f, 1, 1);
            moneyValue = NewText("Value", w, 40, TextColor, TextAnchor.LowerLeft, FontStyle.Bold);
            Anchor(moneyValue.rectTransform, 0, 0, 1, 0.66f);
        }

        StatBar MakeStat(Transform parent, string label, Color color)
        {
            var w = NewRect(label, parent);
            var le = w.gameObject.AddComponent<LayoutElement>();
            le.flexibleWidth = 1; le.minWidth = 140;

            var lt = NewText("Label", w, 20, Muted, TextAnchor.UpperLeft, FontStyle.Bold);
            lt.text = label;
            Anchor(lt.rectTransform, 0, 0.55f, 1, 1);

            var vt = NewText("Value", w, 26, TextColor, TextAnchor.UpperRight, FontStyle.Bold);
            Anchor(vt.rectTransform, 0, 0.52f, 1, 1);

            var back = NewImage("Back", w, new Color(1, 1, 1, 0.12f), roundSprite);
            back.rectTransform.anchorMin = new Vector2(0, 0.18f);
            back.rectTransform.anchorMax = new Vector2(1, 0.40f);
            back.rectTransform.offsetMin = Vector2.zero; back.rectTransform.offsetMax = Vector2.zero;

            var fill = NewImage("Fill", back.rectTransform, color, roundSprite);
            fill.rectTransform.anchorMin = Vector2.zero;
            fill.rectTransform.anchorMax = new Vector2(0.5f, 1);
            fill.rectTransform.offsetMin = Vector2.zero; fill.rectTransform.offsetMax = Vector2.zero;

            return new StatBar { value = vt, fill = fill.rectTransform, fillImg = fill, color = color };
        }

        void BuildCard(Transform root)
        {
            var cardImg = NewImage("Panel", root, CardColor, roundSprite);
            card = cardImg.rectTransform;
            card.anchorMin = new Vector2(0.04f, 0.03f);
            card.anchorMax = new Vector2(0.96f, 0.86f);
            card.offsetMin = Vector2.zero; card.offsetMax = Vector2.zero;
            cardGroup = card.gameObject.AddComponent<CanvasGroup>();

            panelText = NewText("Body", card, 32, TextColor, TextAnchor.UpperLeft);
            bodyRT = panelText.rectTransform;
            bodyRT.anchorMin = new Vector2(0, 0); bodyRT.anchorMax = new Vector2(1, 1);
            bodyRT.offsetMin = new Vector2(48, 200); bodyRT.offsetMax = new Vector2(-48, -40);

            buttonArea = NewRect("Buttons", card);
            buttonArea.anchorMin = new Vector2(0, 0); buttonArea.anchorMax = new Vector2(1, 0);
            buttonArea.pivot = new Vector2(0.5f, 0);
            buttonArea.sizeDelta = new Vector2(-96, 180);
            buttonArea.anchoredPosition = new Vector2(0, 32);
            var vlg = buttonArea.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 10;
            vlg.childAlignment = TextAnchor.LowerCenter;
            vlg.childControlWidth = true; vlg.childControlHeight = true;
            vlg.childForceExpandWidth = true; vlg.childForceExpandHeight = false;
            card.gameObject.SetActive(false);
        }

        // ---------- backlog overlay ----------
        void BuildLog(Transform root)
        {
            logLayer = NewRect("Backlog", root);
            Anchor(logLayer, 0, 0, 1, 1);
            var shade = NewImage("Shade", logLayer, new Color(0, 0, 0, 0.75f));
            Anchor(shade.rectTransform, 0, 0, 1, 1);
            shade.raycastTarget = true;

            var panel = NewImage("Panel", logLayer, CardColor, roundSprite);
            Anchor(panel.rectTransform, 0.10f, 0.06f, 0.90f, 0.94f);

            var title = NewText("Title", panel.rectTransform, 44, Amber, TextAnchor.MiddleCenter, FontStyle.Bold);
            title.text = "Backlog";
            Anchor(title.rectTransform, 0, 0.90f, 1, 1);

            var viewport = NewImage("Viewport", panel.rectTransform, new Color(0, 0, 0, 0.25f));
            Anchor(viewport.rectTransform, 0.03f, 0.14f, 0.97f, 0.89f);
            viewport.raycastTarget = true;
            viewport.gameObject.AddComponent<RectMask2D>();

            logText = NewText("Content", viewport.rectTransform, 30, TextColor, TextAnchor.UpperLeft);
            var lr = logText.rectTransform;
            lr.anchorMin = new Vector2(0, 1); lr.anchorMax = new Vector2(1, 1); lr.pivot = new Vector2(0.5f, 1);
            lr.offsetMin = new Vector2(28, 0); lr.offsetMax = new Vector2(-28, 0);
            var fit = logText.gameObject.AddComponent<ContentSizeFitter>();
            fit.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            logScroll = viewport.gameObject.AddComponent<ScrollRect>();
            logScroll.viewport = viewport.rectTransform;
            logScroll.content = lr;
            logScroll.horizontal = false;
            logScroll.vertical = true;
            logScroll.movementType = ScrollRect.MovementType.Clamped;
            logScroll.scrollSensitivity = 45f;

            var close = AddButton(panel.rectTransform, "Close", CloseModal, BtnGo, 70f, true, 30);
            StyleGo(close);
            var cr = close.GetComponent<RectTransform>();
            cr.anchorMin = new Vector2(0.35f, 0.025f); cr.anchorMax = new Vector2(0.65f, 0.115f);
            cr.offsetMin = Vector2.zero; cr.offsetMax = Vector2.zero;

            logLayer.gameObject.SetActive(false);
        }

        void OpenLog()
        {
            if (modalOpen) return;
            PlaySfx("click");
            modalOpen = true;
            var sb = new StringBuilder();
            int start = Mathf.Max(0, log.Count - MaxLog);
            for (int i = start; i < log.Count; i++)
            {
                var e = log[i];
                if (e.speaker == "Choice")
                    sb.Append("<color=#f8c248>> " + e.text + "</color>\n\n");
                else if (string.IsNullOrEmpty(e.speaker))
                    sb.Append("<i><color=#c9d3e6>" + e.text + "</color></i>\n\n");
                else
                    sb.Append("<b><color=#" + ColorUtility.ToHtmlStringRGB(SpeakerColor(e.speaker)) + ">" + e.speaker + "</color></b>\n" + e.text + "\n\n");
            }
            if (sb.Length == 0) sb.Append("<color=#9eabc2>Nothing here yet.</color>");
            logText.text = sb.ToString();
            logLayer.gameObject.SetActive(true);
            if (scrollCo != null) StopCoroutine(scrollCo);
            scrollCo = StartCoroutine(ScrollLogToBottom());
        }

        IEnumerator ScrollLogToBottom()
        {
            yield return null;
            Canvas.ForceUpdateCanvases();
            logScroll.verticalNormalizedPosition = 0f;
            scrollCo = null;
        }

        void CloseModal()
        {
            logLayer.gameObject.SetActive(false);
            slotLayer.gameObject.SetActive(false);
            modalOpen = false;
        }

        // ---------- save / load overlay ----------
        void BuildSlots(Transform root)
        {
            slotLayer = NewRect("Slots", root);
            Anchor(slotLayer, 0, 0, 1, 1);
            var shade = NewImage("Shade", slotLayer, new Color(0, 0, 0, 0.75f));
            Anchor(shade.rectTransform, 0, 0, 1, 1);
            shade.raycastTarget = true;

            var panel = NewImage("Panel", slotLayer, CardColor, roundSprite);
            Anchor(panel.rectTransform, 0.20f, 0.12f, 0.80f, 0.88f);

            slotTitle = NewText("Title", panel.rectTransform, 46, Amber, TextAnchor.MiddleCenter, FontStyle.Bold);
            Anchor(slotTitle.rectTransform, 0, 0.88f, 1, 1);

            slotList = NewRect("List", panel.rectTransform);
            Anchor(slotList, 0.05f, 0.17f, 0.95f, 0.87f);
            var vlg = slotList.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 14;
            vlg.childAlignment = TextAnchor.UpperCenter;
            vlg.childControlWidth = true; vlg.childControlHeight = true;
            vlg.childForceExpandWidth = true; vlg.childForceExpandHeight = false;

            var close = AddButton(panel.rectTransform, "Close", CloseModal, BtnGo, 70f, true, 30);
            StyleGo(close);
            var cr = close.GetComponent<RectTransform>();
            cr.anchorMin = new Vector2(0.30f, 0.035f); cr.anchorMax = new Vector2(0.70f, 0.125f);
            cr.offsetMin = Vector2.zero; cr.offsetMax = Vector2.zero;

            slotLayer.gameObject.SetActive(false);
        }

        void OpenSlots(bool saveMode)
        {
            if (modalOpen) return;
            if (saveMode && s == null) return;
            PlaySfx("click");
            modalOpen = true;
            slotTitle.text = saveMode ? "Save game" : "Load game";
            ClearChildren(slotList);
            for (int slot = 0; slot <= SlotCount; slot++)
            {
                int n = slot;
                var d = ReadSave(n);
                string name = n == 0 ? "Autosave" : "Slot " + n;
                string info = d == null
                    ? "<color=#8b93a6>Empty</color>"
                    : d.label + "\n<size=22><color=#c9d3e6>" + d.stamp + "   -   " + cur + d.money.ToString("N0", CultureInfo.InvariantCulture) + " savings</color></size>";
                bool ok = saveMode ? n != 0 : d != null;
                AddButton(slotList, "<b>" + name + "</b>   " + info, () => OnSlot(n, saveMode), ok ? BtnColor : BtnOff, 100f, ok, 28);
            }
            slotLayer.gameObject.SetActive(true);
        }

        void OnSlot(int slot, bool saveMode)
        {
            if (saveMode)
            {
                SaveToSlot(slot);
                CloseModal();
                PlaySfx("save");
                Toast("<color=#7bd88f>Game saved (slot " + slot + ")</color>");
            }
            else
            {
                CloseModal();
                LoadFromSlot(slot);
            }
        }

        // =====================================================================
        //  SAVE / LOAD
        // =====================================================================
        static string SlotKey(int slot) { return "panganay_save_" + slot; }

        SaveData ReadSave(int slot)
        {
            string json = PlayerPrefs.GetString(SlotKey(slot), "");
            if (string.IsNullOrEmpty(json)) return null;
            try { return JsonUtility.FromJson<SaveData>(json); }
            catch (Exception) { return null; }
        }

        bool AnySave()
        {
            for (int i = 0; i <= SlotCount; i++) if (ReadSave(i) != null) return true;
            return false;
        }

        void SaveToSlot(int slot)
        {
            if (s == null || chapters == null) return;
            var d = new SaveData
            {
                money = s.money, energy = s.energy, grades = s.grades, family = s.family,
                planning = s.planning, debt = s.debt,
                flags = new List<string>(s.flags).ToArray(),
                ci = ci, si = resumeIndex,
                bg = currentBg, music = currentMusic,
                label = chapters[ci].title + " - " + chapters[ci].subtitle,
                stamp = DateTime.Now.ToString("MMM d, HH:mm", CultureInfo.InvariantCulture)
            };
            PlayerPrefs.SetString(SlotKey(slot), JsonUtility.ToJson(d));
            PlayerPrefs.Save();
        }

        void LoadFromSlot(int slot)
        {
            var d = ReadSave(slot);
            if (d == null) return;
            s = new GameState
            {
                money = d.money, energy = d.energy, grades = d.grades, family = d.family,
                planning = d.planning, debt = d.debt
            };
            s.flags = new HashSet<string>(d.flags ?? new string[0]);
            chapters = Content.Build();
            ci = Mathf.Clamp(d.ci, 0, chapters.Count - 1);
            si = Mathf.Max(0, d.si);
            s.week = ci + 1;
            rightName = null;
            log.Clear();
            autoOn = skipOn = false; UpdateQuickButtons();
            var ch = chapters[ci];
            SetHeader(ch.title + " of " + chapters.Count, ch.subtitle);
            currentBg = null;
            SetBackground(string.IsNullOrEmpty(d.bg) ? ch.bg : d.bg);
            PlayMusic(string.IsNullOrEmpty(d.music) ? ch.music : d.music);
            RefreshHud();
            SnapBars();
            FadeFromBlack(0.8f);
            NextStep();
        }

        // ---------- "already read" memory for Skip ----------
        static int Hash(string str)
        {
            unchecked
            {
                uint h = 2166136261;
                for (int i = 0; i < str.Length; i++) { h ^= str[i]; h *= 16777619; }
                return (int)h;
            }
        }

        void LoadSeen()
        {
            string data = PlayerPrefs.GetString("panganay_seen", "");
            if (string.IsNullOrEmpty(data)) return;
            foreach (var part in data.Split(','))
            {
                int v;
                if (int.TryParse(part, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out v)) seen.Add(v);
            }
        }

        void SaveSeen()
        {
            var sb = new StringBuilder();
            bool first = true;
            foreach (int v in seen)
            {
                if (!first) sb.Append(',');
                sb.Append(v.ToString("x"));
                first = false;
            }
            PlayerPrefs.SetString("panganay_seen", sb.ToString());
            PlayerPrefs.Save();
        }

        // =====================================================================
        //  BUTTONS
        // =====================================================================
        static void ClearChildren(RectTransform parent)
        {
            for (int i = parent.childCount - 1; i >= 0; i--)
            {
                var child = parent.GetChild(i);
                child.SetParent(null, false);   // leave the layout immediately; Destroy only happens at end of frame
                Destroy(child.gameObject);
            }
        }

        Button AddButton(Transform parent, string label, Action onClick, Color color, float height = 76f,
                         bool interactable = true, int fontSize = 30)
        {
            var rt = NewRect("Button", parent);
            var img = rt.gameObject.AddComponent<Image>();
            img.sprite = roundSprite; img.type = Image.Type.Sliced; img.color = color;
            var btn = rt.gameObject.AddComponent<Button>();
            btn.targetGraphic = img;
            var cb = btn.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(0.85f, 0.85f, 0.85f, 1f);
            cb.pressedColor = new Color(0.65f, 0.65f, 0.65f, 1f);
            cb.disabledColor = new Color(0.55f, 0.55f, 0.55f, 0.85f);
            cb.fadeDuration = 0.08f;
            btn.colors = cb;
            btn.interactable = interactable;
            var nav = new Navigation(); nav.mode = Navigation.Mode.None;
            btn.navigation = nav;
            var le = rt.gameObject.AddComponent<LayoutElement>();
            le.minHeight = height; le.preferredHeight = height;

            var t = NewText("Label", rt, fontSize, TextColor, TextAnchor.MiddleLeft);
            t.text = label.Replace("{P}", cur);
            Anchor(t.rectTransform, 0, 0, 1, 1);
            t.rectTransform.offsetMin = new Vector2(28, 4);
            t.rectTransform.offsetMax = new Vector2(-28, -4);

            btn.onClick.AddListener(() =>
            {
                if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
                onClick();
            });
            return btn;
        }

        void StyleGo(Button b)
        {
            var t = b.GetComponentInChildren<Text>();
            t.alignment = TextAnchor.MiddleCenter;
            t.color = new Color(0.12f, 0.10f, 0.05f);
            t.fontStyle = FontStyle.Bold;
        }

        // =====================================================================
        //  MODES
        // =====================================================================
        void StopTyping()
        {
            if (typeCo != null) { StopCoroutine(typeCo); typeCo = null; }
            typing = false;
        }

        void EnterVN()
        {
            card.gameObject.SetActive(false);
            captionLayer.gameObject.SetActive(false);
            vnLayer.gameObject.SetActive(true);
            catcher.gameObject.SetActive(true);
            dim.color = new Color(0f, 0f, 0f, 0.18f);
        }

        void EnterCaption()
        {
            StopTyping();
            pending = null;
            ClearChildren(choicesArea);
            vnLayer.gameObject.SetActive(false);
            leftChar.rt.gameObject.SetActive(false);
            rightChar.rt.gameObject.SetActive(false);
            card.gameObject.SetActive(false);
            captionLayer.gameObject.SetActive(true);
            catcher.gameObject.SetActive(true);
            dim.color = new Color(0f, 0f, 0f, 0.55f);
        }

        void EnterPanel()
        {
            StopTyping();
            pending = null;
            ClearChildren(choicesArea);
            vnLayer.gameObject.SetActive(false);
            leftChar.rt.gameObject.SetActive(false);
            rightChar.rt.gameObject.SetActive(false);
            captionLayer.gameObject.SetActive(false);
            catcher.gameObject.SetActive(false);
            card.gameObject.SetActive(true);
            dim.color = new Color(0f, 0f, 0f, 0.55f);
        }

        // =====================================================================
        //  TRANSITIONS
        // =====================================================================
        void FadeFromBlack(float seconds)
        {
            if (blackCo != null) StopCoroutine(blackCo);
            blackCo = StartCoroutine(FadeFromBlackRoutine(seconds));
        }

        IEnumerator FadeFromBlackRoutine(float seconds)
        {
            float t = 0f;
            fadeOverlay.color = new Color(0, 0, 0, 1f);
            while (t < seconds)
            {
                t += Time.unscaledDeltaTime;
                fadeOverlay.color = new Color(0, 0, 0, 1f - Mathf.Clamp01(t / seconds));
                yield return null;
            }
            fadeOverlay.color = new Color(0, 0, 0, 0f);
            blackCo = null;
        }

        IEnumerator FadeGroup(CanvasGroup g, float seconds)
        {
            float t = 0f;
            g.alpha = 0f;
            while (t < seconds)
            {
                t += Time.unscaledDeltaTime;
                g.alpha = Mathf.Clamp01(t / seconds);
                yield return null;
            }
            g.alpha = 1f;
        }

        void AnimateChar(CharView cv, float dt)
        {
            if (cv == null || !cv.rt.gameObject.activeSelf) return;
            cv.curA = Mathf.MoveTowards(cv.curA, cv.tgtA, 3.2f * dt);
            cv.curX = Mathf.Lerp(cv.curX, cv.tgtX, Mathf.Clamp01(9f * dt));
            cv.curS = Mathf.Lerp(cv.curS, cv.tgtS, Mathf.Clamp01(9f * dt));
            cv.group.alpha = cv.curA;
            cv.rt.anchoredPosition = new Vector2(cv.curX, 0f);
            cv.rt.localScale = new Vector3(cv.curS, cv.curS, 1f);
        }

        // =====================================================================
        //  VISUAL-NOVEL DIALOGUE
        // =====================================================================
        void Say(string speaker, string text, Action next)
        {
            EnterVN();
            UpdateCharacters(speaker);

            bool has = !string.IsNullOrEmpty(speaker);
            nameTag.gameObject.SetActive(has);
            if (has)
            {
                nameTag.color = SpeakerColor(speaker) * 0.85f;
                nameText.text = speaker;
            }
            vnText.fontStyle = has ? FontStyle.Normal : FontStyle.Italic;
            vnText.color = has ? TextColor : NarrationColor;

            pending = next;
            typeFull = text.Replace("{P}", cur);
            int len = VisibleLength(typeFull);
            vnText.fontSize = len > 380 ? 27 : (len > 270 ? 30 : 34);   // long lines shrink so they fit the box
            blipOn = has;
            autoTimer = 0f;

            // remember what has been read (for Skip) and add to the backlog
            int key = Hash((speaker ?? "") + "|" + text);
            currentSeen = seen.Contains(key);
            seen.Add(key);
            log.Add(new LogEntry { speaker = speaker, text = typeFull });
            if (log.Count > MaxLog + 50) log.RemoveRange(0, 50);

            StopTyping();
            typeCo = StartCoroutine(TypeRoutine());
        }

        IEnumerator TypeRoutine()
        {
            typing = true;
            indicator.gameObject.SetActive(false);
            int total = VisibleLength(typeFull);
            float shown = 0f;
            int lastN = 0;
            vnText.text = "";
            while (shown < total)
            {
                shown += CharsPerSecond * Time.unscaledDeltaTime;
                int n = (int)shown;
                vnText.text = Reveal(typeFull, n);
                if (n != lastN)
                {
                    if (blipOn && n % 3 == 0) Blip();
                    lastN = n;
                }
                yield return null;
            }
            typeCo = null;
            EndTyping();
        }

        void EndTyping()
        {
            typing = false;
            vnText.text = typeFull;
            indicator.gameObject.SetActive(pending != null);
        }

        void OnAdvance()
        {
            if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
            if (typing)
            {
                if (typeCo != null) { StopCoroutine(typeCo); typeCo = null; }
                EndTyping();
                return;
            }
            if (pending == null) return;
            var p = pending;
            pending = null;
            indicator.gameObject.SetActive(false);
            p();
        }

        // Returns the first `count` visible characters of `full`, keeping rich-text tags balanced.
        static string Reveal(string full, int count)
        {
            var sb = new StringBuilder();
            var open = new List<string>();
            int vis = 0, i = 0;
            while (i < full.Length)
            {
                char c = full[i];
                if (c == '<')
                {
                    int e = full.IndexOf('>', i);
                    if (e > i)
                    {
                        string tag = full.Substring(i, e - i + 1);
                        string name = tag.Substring(1, tag.Length - 2);
                        if (name.StartsWith("/")) { if (open.Count > 0) open.RemoveAt(open.Count - 1); }
                        else
                        {
                            int sp = name.IndexOfAny(new char[] { ' ', '=' });
                            open.Add(sp > 0 ? name.Substring(0, sp) : name);
                        }
                        sb.Append(tag);
                        i = e + 1;
                        continue;
                    }
                }
                if (vis >= count) break;
                sb.Append(c);
                vis++; i++;
            }
            for (int k = open.Count - 1; k >= 0; k--) sb.Append("</" + open[k] + ">");
            return sb.ToString();
        }

        static int VisibleLength(string full)
        {
            if (string.IsNullOrEmpty(full)) return 0;
            int vis = 0, i = 0;
            while (i < full.Length)
            {
                if (full[i] == '<')
                {
                    int e = full.IndexOf('>', i);
                    if (e > i) { i = e + 1; continue; }
                }
                vis++; i++;
            }
            return vis;
        }

        // ---------- characters ----------
        void UpdateCharacters(string speaker)
        {
            if (!string.IsNullOrEmpty(speaker) && speaker != Content.Mark) rightName = speaker;

            ApplyChar(leftChar, Content.Mark, speaker == Content.Mark);
            if (rightName != null) ApplyChar(rightChar, rightName, speaker == rightName);
            else rightChar.rt.gameObject.SetActive(false);
        }

        void ApplyChar(CharView cv, string name, bool active)
        {
            bool appearing = !cv.rt.gameObject.activeSelf || cv.name != name;
            cv.rt.gameObject.SetActive(true);
            if (cv.name != name)
            {
                cv.name = name;
                var art = LoadSprite("Characters/" + name);
                cv.hasArt = art != null;
                if (cv.hasArt)
                {
                    cv.img.sprite = art;
                    cv.img.type = Image.Type.Simple;
                    cv.img.preserveAspect = true;
                    cv.label.gameObject.SetActive(false);
                }
                else
                {
                    // Placeholder silhouette until you add art.
                    cv.img.sprite = circleSprite;
                    cv.img.type = Image.Type.Sliced;
                    cv.img.preserveAspect = false;
                    cv.label.gameObject.SetActive(true);
                    cv.label.text = "<size=120>" + name.Substring(0, 1).ToUpperInvariant() + "</size>\n" + name;
                }
            }
            if (appearing)
            {
                cv.curA = 0f;
                cv.curX = cv.side * 90f;
                cv.curS = 0.97f;
            }
            cv.tgtA = 1f; cv.tgtX = 0f;
            cv.tgtS = active ? 1.03f : 0.97f;

            if (cv.hasArt)
            {
                float v = active ? 1f : 0.55f;
                cv.img.color = new Color(v, v, v, 1f);
            }
            else
            {
                Color c = SpeakerColor(name);
                cv.img.color = new Color(c.r, c.g, c.b, active ? 0.78f : 0.30f);
                cv.label.color = new Color(1f, 1f, 1f, active ? 1f : 0.5f);
            }
        }

        // ---------- toast ----------
        void Toast(string rich)
        {
            if (toastCo != null) StopCoroutine(toastCo);
            if (string.IsNullOrEmpty(rich)) { toast.gameObject.SetActive(false); return; }
            toast.text = rich;
            toastCo = StartCoroutine(ToastRoutine());
        }

        IEnumerator ToastRoutine()
        {
            toast.gameObject.SetActive(true);
            toast.color = Color.white;
            yield return new WaitForSecondsRealtime(4.5f);
            float t = 0f;
            while (t < 0.5f)
            {
                t += Time.unscaledDeltaTime;
                toast.color = new Color(1f, 1f, 1f, 1f - Mathf.Clamp01(t / 0.5f));
                yield return null;
            }
            toast.gameObject.SetActive(false);
            toastCo = null;
        }

        // =====================================================================
        //  CAPTION + PANEL SCREENS
        // =====================================================================
        void ShowCaption(string text, string label, Action action, bool withLoad = false)
        {
            EnterCaption();
            captionText.text = text.Replace("{P}", cur);
            ClearChildren(captionButtons);
            bool load = withLoad && AnySave();
            captionButtons.sizeDelta = new Vector2(520, load ? 190f : 100f);
            var b = AddButton(captionButtons, label, action, BtnGo, 80f, true, 32);
            StyleGo(b);
            if (load)
            {
                var lb = AddButton(captionButtons, "Load game", () => OpenSlots(false), BtnColor, 80f, true, 32);
                var lt = lb.GetComponentInChildren<Text>();
                lt.alignment = TextAnchor.MiddleCenter; lt.fontStyle = FontStyle.Bold;
            }
            pending = action;
            if (captionCo != null) StopCoroutine(captionCo);
            captionCo = StartCoroutine(FadeGroup(captionGroup, 0.6f));
        }

        void PresentPanel(string body, bool fade = true, int fontSize = 32, TextAnchor align = TextAnchor.UpperLeft)
        {
            EnterPanel();
            panelText.fontSize = fontSize;
            panelText.alignment = align;
            panelText.text = body.Replace("{P}", cur);
            if (fade)
            {
                if (fadeCo != null) StopCoroutine(fadeCo);
                fadeCo = StartCoroutine(FadeGroup(cardGroup, 0.25f));
            }
        }

        void SetPanelLayout(float buttonsHeight)
        {
            buttonArea.sizeDelta = new Vector2(-96, buttonsHeight);
            bodyRT.offsetMin = new Vector2(48, buttonsHeight + 50);
            bodyRT.offsetMax = new Vector2(-48, -40);
        }

        void PanelContinue(Action onClick, string label = "Continue  >")
        {
            ClearChildren(buttonArea);
            SetPanelLayout(96);
            var b = AddButton(buttonArea, label, onClick, BtnGo, 80f, true, 32);
            StyleGo(b);
        }

        // =====================================================================
        //  HUD
        // =====================================================================
        void RefreshHud()
        {
            if (s == null) return;
            energyBar.target = s.energy; gradesBar.target = s.grades;
            familyBar.target = s.family; planBar.target = s.planning;
            energyBar.value.text = s.energy.ToString();
            gradesBar.value.text = s.grades.ToString();
            familyBar.value.text = s.family.ToString();
            planBar.value.text = s.planning.ToString();

            moneyLabel.text = s.debt > 0
                ? "SAVINGS   <color=#ff7366>DEBT " + cur + s.debt.ToString("N0", CultureInfo.InvariantCulture) + "</color>"
                : "SAVINGS";
            moneyValue.text = cur + s.money.ToString("N0", CultureInfo.InvariantCulture);
            moneyValue.color = s.money < 200 ? Bad : TextColor;
        }

        void SnapBars()
        {
            energyBar.shown = energyBar.target; gradesBar.shown = gradesBar.target;
            familyBar.shown = familyBar.target; planBar.shown = planBar.target;
        }

        void AnimateBar(StatBar b)
        {
            if (b == null) return;
            b.shown = Mathf.MoveTowards(b.shown, b.target, 70f * Time.unscaledDeltaTime);
            b.fill.anchorMax = new Vector2(Mathf.Clamp01(b.shown / 100f), 1f);
            b.fillImg.color = b.shown < 25f ? Bad : b.color;
        }

        void SetHeader(string title, string sub)
        {
            headerTitle.text = title;
            headerSub.text = sub;
        }

        // =====================================================================
        //  FLOW
        // =====================================================================
        void ShowTitle()
        {
            s = null;
            rightName = null;
            autoOn = skipOn = false; UpdateQuickButtons();
            log.Clear();
            SetBackground("title");
            PlayMusic("title");
            SetHeader("", "");
            energyBar.target = gradesBar.target = familyBar.target = planBar.target = 0;
            energyBar.value.text = gradesBar.value.text = familyBar.value.text = planBar.value.text = "";
            moneyLabel.text = ""; moneyValue.text = "";

            ShowCaption(
                "<size=120><b>" + Content.GameTitle + "</b></size>\n\n" + Content.Tagline +
                "\n\n<size=24><color=#c9d3e6>" + Content.ContentNote + "</color></size>",
                "Start", StartGame, true);
        }

        void StartGame()
        {
            s = new GameState();
            chapters = Content.Build();
            ci = -1;
            NextChapter();
        }

        void NextChapter()
        {
            ci++;
            if (ci >= chapters.Count) { ShowEnding(); return; }
            si = 0;
            resumeIndex = 0;
            rightName = null;
            s.week = ci + 1;
            if (ci > 0) s.Apply(new Effects(energy: 8)); // a new week brings a little rest
            var ch = chapters[ci];
            SetBackground(ch.bg);
            PlayMusic(ch.music);
            SetHeader(ch.title + " of " + chapters.Count, ch.subtitle);
            RefreshHud();
            SaveToSlot(0);                                 // autosave at the start of every week
            FadeFromBlack(0.9f);
            PlaySfx("chapter");
            ShowCaption(
                "<size=90><b>" + ch.title + "</b></size>\n\n<size=46><color=#f8c248>" + ch.subtitle + "</color></size>",
                "Begin", NextStep);
        }

        void NextStep()
        {
            var ch = chapters[ci];
            while (si < ch.steps.Count)
            {
                var st = ch.steps[si++];
                if (st.showIf != null && !st.showIf(s)) continue;
                ShowStep(st);
                return;
            }
            ShowWeekEnd();
        }

        void ShowStep(Step st)
        {
            RefreshHud();
            resumeIndex = si - 1;                 // loading a save re-shows this step
            if (!string.IsNullOrEmpty(st.bg)) SetBackground(st.bg);
            if (!string.IsNullOrEmpty(st.music)) PlayMusic(st.music);
            switch (st.type)
            {
                case StepType.Story:
                    Say(st.speaker, st.textFn != null ? st.textFn(s) : st.text, NextStep);
                    break;
                case StepType.Choice:
                    ShowChoice(st);
                    break;
                case StepType.Budget:
                    budgetStep = st;
                    paid = new bool[st.items.Count];
                    for (int i = 0; i < paid.Length; i++) paid[i] = true;
                    RenderBudget(true);
                    break;
            }
        }

        // ---------- choices ----------
        void ShowChoice(Step st)
        {
            Say(st.speaker, st.text, null);   // the prompt types out; choices appear right away
            ClearChildren(choicesArea);
            choicesArea.sizeDelta = new Vector2(1300, st.choices.Count * 98f);
            foreach (var ch in st.choices)
            {
                var choice = ch;
                bool ok = choice.requires == null || choice.requires(s);
                string label = ok ? choice.text
                    : "<color=#8b93a6>" + choice.text + "</color>\n<size=22><color=#f8c248>" + choice.lockedHint + "</color></size>";
                AddButton(choicesArea, label, () => OnChoice(choice), ok ? BtnColor : BtnOff, 84f, ok, 28);
            }
        }

        void OnChoice(Choice c)
        {
            ClearChildren(choicesArea);
            log.Add(new LogEntry { speaker = "Choice", text = c.text.Replace("{P}", cur) });
            string note = ApplyEffects(c.fx, c.fx.energy + c.fx.grades + c.fx.family + c.fx.planning + (c.fx.money / 100));
            if (!string.IsNullOrEmpty(c.setFlag)) s.flags.Add(c.setFlag);
            RefreshHud();
            resumeIndex = si;                     // the choice is made; a save from here resumes after it
            Say(null, c.result, NextStep);
            Toast(note);
        }

        string ApplyEffects(Effects e, int balance)
        {
            int shortBy = s.Apply(e);
            string d = Describe(e);
            if (shortBy > 0)
                d += (d.Length > 0 ? "   " : "") + "<color=#ff7366>Short by " + cur + shortBy.ToString("N0", CultureInfo.InvariantCulture) + ". The rest goes on debt.</color>";
            if (d.Length > 0) PlaySfx(balance >= 0 && shortBy == 0 && e.debt == 0 ? "gain" : "loss");
            return d;
        }

        string Describe(Effects e)
        {
            var parts = new List<string>();
            if (e.money != 0) parts.Add(Delta(e.money, "", true));
            if (e.energy != 0) parts.Add(Delta(e.energy, "Energy", false));
            if (e.grades != 0) parts.Add(Delta(e.grades, "Grades", false));
            if (e.family != 0) parts.Add(Delta(e.family, "Family", false));
            if (e.planning != 0) parts.Add(Delta(e.planning, "Planning", false));
            if (e.debt > 0) parts.Add("<color=#ff7366>Debt +" + cur + e.debt.ToString("N0", CultureInfo.InvariantCulture) + "</color>");
            return string.Join("   ", parts.ToArray());
        }

        string Delta(int v, string label, bool money)
        {
            string col = v > 0 ? "#7bd88f" : "#ff7366";
            string sign = v > 0 ? "+" : "-";
            string amt = money ? cur + Mathf.Abs(v).ToString("N0", CultureInfo.InvariantCulture)
                               : Mathf.Abs(v).ToString() + " " + label;
            return "<color=" + col + ">" + sign + amt + "</color>";
        }

        // ---------- budget ----------
        void RenderBudget(bool fade)
        {
            var st = budgetStep;
            int loan = Mathf.Min(s.debt, 300);
            int available = s.money + st.income - loan;
            int spend = 0;
            for (int i = 0; i < st.items.Count; i++) if (paid[i]) spend += st.items[i].cost;
            int left = available - spend;

            var sb = new StringBuilder();
            sb.Append("<b>Weekly budget</b>   <size=24><color=#9eabc2>Tap an item to pay it or skip it. Whatever is left is saved.</color></size>\n");
            sb.Append("Pay this week: " + cur + st.income.ToString("N0", CultureInfo.InvariantCulture));
            sb.Append("   +   Savings: " + cur + s.money.ToString("N0", CultureInfo.InvariantCulture));
            if (loan > 0) sb.Append("   -   <color=#ff7366>Loan payment: " + cur + loan.ToString("N0", CultureInfo.InvariantCulture) + "</color>");
            sb.Append("\nAvailable: <b>" + cur + available.ToString("N0", CultureInfo.InvariantCulture) + "</b>");
            sb.Append("   Selected: <b>" + cur + spend.ToString("N0", CultureInfo.InvariantCulture) + "</b>");
            sb.Append("   Left to save: <b><color=" + (left >= 0 ? "#7bd88f" : "#ff7366") + ">" + cur + left.ToString("N0", CultureInfo.InvariantCulture) + "</color></b>");
            if (left < 0) sb.Append("\n<size=26><color=#ff7366>You can't afford everything. Skip something.</color></size>");

            PresentPanel(sb.ToString(), fade, 28);
            ClearChildren(buttonArea);
            float rowH = 78f;
            SetPanelLayout(st.items.Count * (rowH + 10f) + 90f);

            for (int i = 0; i < st.items.Count; i++)
            {
                int idx = i;
                var it = st.items[i];
                string mark = paid[i] ? "[x]" : "[  ]";
                string sub = it.required ? "Required" : (paid[i] ? "Paid" : "If skipped: " + it.skipHint);
                string label = mark + "  " + it.name + "  -  " + cur + it.cost.ToString("N0", CultureInfo.InvariantCulture)
                    + "\n<size=22><color=#c9d3e6>" + sub + "</color></size>";
                AddButton(buttonArea, label, () => { if (!st.items[idx].required) { paid[idx] = !paid[idx]; PlaySfx("click"); RenderBudget(false); } },
                          paid[i] ? BtnOn : BtnOff, rowH, true, 28);
            }
            var go = AddButton(buttonArea, "Confirm budget  >", () => ConfirmBudget(loan, left), BtnGo, 80f, left >= 0, 32);
            StyleGo(go);
        }

        void ConfirmBudget(int loan, int left)
        {
            var st = budgetStep;
            s.money = left;
            s.debt -= loan;
            Effects total = new Effects();
            var skipped = new List<string>();
            for (int i = 0; i < st.items.Count; i++)
            {
                if (paid[i]) total = total.Plus(st.items[i].ifPaid);
                else { total = total.Plus(st.items[i].ifSkipped); skipped.Add(st.items[i].name + ": " + st.items[i].skipHint); }
            }
            s.Apply(total);
            RefreshHud();
            resumeIndex = si;

            var sb = new StringBuilder();
            sb.Append("Budget settled. " + cur + left.ToString("N0", CultureInfo.InvariantCulture) + " goes into savings.");
            if (loan > 0) sb.Append(" You paid " + cur + loan.ToString("N0", CultureInfo.InvariantCulture) + " toward the loan.");
            if (skipped.Count > 0)
            {
                sb.Append("\n\n<b>You skipped:</b>");
                foreach (var line in skipped) sb.Append("\n<size=26>- " + line + "</size>");
            }
            string d = Describe(total);
            if (d.Length > 0) sb.Append("\n\n<size=26>" + d + "</size>");
            PresentPanel(sb.ToString(), true, 30);
            PanelContinue(NextStep);
        }

        // ---------- week end ----------
        void ShowWeekEnd()
        {
            Effects fx;
            string text = Content.WeekEnd(s, out fx);
            bool last = ci == chapters.Count - 1;
            if (last && s.money >= 400)
            {
                fx = fx.Plus(new Effects(planning: 3));
                text += "\n\nYou finish with " + cur + s.money.ToString("N0", CultureInfo.InvariantCulture) + " untouched in savings. A real cushion for the first time.";
            }
            s.Apply(fx);
            RefreshHud();
            string d = Describe(fx);
            PresentPanel("<b>End of " + chapters[ci].title.ToLowerInvariant() + "</b>\n\n" + text + (d.Length > 0 ? "\n\n<size=26>" + d + "</size>" : ""), true, 30);
            PanelContinue(last ? (Action)ShowEnding : NextChapter, last ? "See what happens  >" : "Next week  >");
        }

        void ShowEnding()
        {
            string title, body;
            Content.Ending(s, out title, out body);
            SetBackground("ending");
            PlayMusic(Content.EndingMusic(title));
            SetHeader("THE END", "");
            SaveSeen();
            FadeFromBlack(1.2f);
            PlaySfx("chapter");
            PresentPanel("<size=56><b><color=#f8c248>" + title + "</color></b></size>\n\n" + body, true, 28);
            PanelContinue(ShowTakeaways);
        }

        void ShowTakeaways()
        {
            PresentPanel(Content.Takeaways, true, 27);
            ClearChildren(buttonArea);
            SetPanelLayout(96);
            var b = AddButton(buttonArea, "Play again", ShowTitle, BtnGo, 80f, true, 32);
            StyleGo(b);
        }
    }
}
