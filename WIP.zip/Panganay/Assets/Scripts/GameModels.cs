using System;
using System.Collections.Generic;

// Pure C# data + state. No UnityEngine dependency, so it is easy to test and edit.
namespace Panganay
{
    /// <summary>Changes applied to the game state. Positive or negative.</summary>
    public class Effects
    {
        public int money, energy, grades, family, planning, debt;

        public Effects(int money = 0, int energy = 0, int grades = 0, int family = 0, int planning = 0, int debt = 0)
        {
            this.money = money; this.energy = energy; this.grades = grades;
            this.family = family; this.planning = planning; this.debt = debt;
        }

        public Effects Plus(Effects o)
        {
            return new Effects(money + o.money, energy + o.energy, grades + o.grades,
                               family + o.family, planning + o.planning, debt + o.debt);
        }
    }

    public class Choice
    {
        public string text;
        public Effects fx = new Effects();
        public string result;                       // shown after picking
        public string setFlag;                      // optional story flag
        public Func<GameState, bool> requires;      // optional lock condition
        public string lockedHint;                   // shown when locked
    }

    public class BudgetItem
    {
        public string name;
        public int cost;
        public bool required;
        public string skipHint;                     // what happens if you skip it
        public Effects ifSkipped = new Effects();
        public Effects ifPaid = new Effects();
    }

    public enum StepType { Story, Choice, Budget }

    public class Step
    {
        public StepType type;
        public string speaker;                      // null = narration
        public string text;
        public Func<GameState, string> textFn;      // optional: text that depends on state
        public Func<GameState, bool> showIf;        // optional: skip step when false
        public List<Choice> choices;
        public int income;
        public List<BudgetItem> items;
        public string bg;                           // optional: switch background when this step starts

        public string music;                        // optional: switch music when this step starts

        public Step Bg(string name) { bg = name; return this; }
        public Step Music(string name) { music = name; return this; }
    }

    public class Chapter
    {
        public string title;                        // "WEEK 1"
        public string subtitle;                     // "Monday, 5:40 AM"
        public string bg;                           // default background for the chapter
        public string music;                        // default music for the chapter
        public List<Step> steps = new List<Step>();
    }

    public class GameState
    {
        public int money = 300;     // savings
        public int energy = 70;
        public int grades = 65;
        public int family = 60;     // family bond / harmony
        public int planning = 0;    // how much the family has learned to plan together
        public int debt = 0;
        public int week = 0;
        public HashSet<string> flags = new HashSet<string>();

        public bool Has(string flag) { return flags.Contains(flag); }

        static int Clamp(int v) { return v < 0 ? 0 : (v > 100 ? 100 : v); }

        /// <summary>Applies effects. Returns how much money was missing and had to become debt.</summary>
        public int Apply(Effects e)
        {
            int shortBy = 0;
            money += e.money;
            if (money < 0) { shortBy = -money; debt += shortBy; money = 0; }
            debt += e.debt;
            energy = Clamp(energy + e.energy);
            grades = Clamp(grades + e.grades);
            family = Clamp(family + e.family);
            planning = Clamp(planning + e.planning);
            return shortBy;
        }
    }
}
