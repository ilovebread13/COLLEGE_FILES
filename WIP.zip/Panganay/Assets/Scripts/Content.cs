using System;
using System.Collections.Generic;

// ALL the story lives in this file. Edit freely: names, dialogue, prices, effects.
// "{P}" is replaced by the peso sign at runtime.
namespace Panganay
{
    public static class Content
    {
        public const string GameTitle = "PANGANAY";
        public const string Tagline = "The eldest carries a lot.\nHe doesn't have to carry it alone.";
        public const string ContentNote = "A fictional story about family life in the Philippines.\nThemes: financial hardship, a child's illness, family conflict.";

        // Speakers (used for the portrait color/initial).
        public const string Mark = "Mark", Mama = "Mama Liza", Tatay = "Tatay Ramon",
            Bea = "Bea", Jun = "Jun", Lyn = "Lyn", Midwife = "Midwife Grace",
            Boss = "Boss Dom", Prof = "Prof. Reyes";

        // ---------- small helpers to keep the story readable ----------
        static Effects Fx(int money = 0, int energy = 0, int grades = 0, int family = 0, int planning = 0, int debt = 0)
        {
            return new Effects(money, energy, grades, family, planning, debt);
        }

        static Step Story(string speaker, string text, Func<GameState, bool> showIf = null)
        {
            return new Step { type = StepType.Story, speaker = speaker, text = text, showIf = showIf };
        }

        static Step StoryFn(string speaker, Func<GameState, string> textFn, Func<GameState, bool> showIf = null)
        {
            return new Step { type = StepType.Story, speaker = speaker, textFn = textFn, showIf = showIf };
        }

        static Step WithBg(string bg, Step s) { s.bg = bg; return s; }

        static Step Ask(string speaker, string prompt, params Choice[] choices)
        {
            return new Step { type = StepType.Choice, speaker = speaker, text = prompt, choices = new List<Choice>(choices) };
        }

        static Choice Pick(string text, Effects fx, string result, string flag = null,
                           Func<GameState, bool> requires = null, string locked = null)
        {
            return new Choice { text = text, fx = fx, result = result, setFlag = flag, requires = requires, lockedHint = locked };
        }

        static BudgetItem Item(string name, int cost, string skipHint, Effects ifSkipped,
                               bool required = false, Effects ifPaid = null)
        {
            return new BudgetItem
            {
                name = name, cost = cost, required = required, skipHint = skipHint,
                ifSkipped = ifSkipped ?? new Effects(), ifPaid = ifPaid ?? new Effects()
            };
        }

        static Step Budget(int income, params BudgetItem[] items)
        {
            return new Step { type = StepType.Budget, income = income, items = new List<BudgetItem>(items) };
        }

        // Standard weekly items (max 5 rows fit on screen).
        static BudgetItem Fare() { return Item("Fare to school and work", 350, "", null, true); }
        static BudgetItem Food() { return Item("Food for the house", 500, "the family goes hungry. Energy and family bond drop.", Fx(energy: -4, family: -8)); }
        static BudgetItem Power() { return Item("Electricity bill (your share)", 350, "lights out at night. Harder to study, tempers rise.", Fx(energy: -2, family: -5, grades: -2)); }
        static BudgetItem Siblings() { return Item("Siblings' school needs and baon", 250, "the little ones go without supplies and snacks.", Fx(family: -5)); }
        static BudgetItem School(int cost = 200) { return Item("Your school projects and printing", cost, "assignments suffer. Grades drop.", Fx(grades: -6)); }

        static Step Evening(string prompt)
        {
            return Ask(null, prompt,
                Pick("Study for a couple of hours.", Fx(energy: -5, grades: 8),
                     "You get through two chapters before your eyes start to close."),
                Pick("Take the manager's overtime offer.", Fx(money: 400, energy: -15, grades: -5),
                     "Extra hours, extra pay. By the end your feet ache and your notes stay closed."),
                Pick("Sleep early. Your body needs it.", Fx(energy: 18),
                     "Nine hours feels like a luxury. You wake up feeling almost human."),
                Pick("Spend the evening with your siblings.", Fx(energy: -3, family: 6),
                     "Migo makes you play 'restaurant' with plastic cups. Lyn grades your cooking. It's the best part of the week."));
        }

        // ---------- the story ----------
        public static List<Chapter> Build()
        {
            var list = new List<Chapter>();

            // ================= WEEK 1 =================
            var w1 = new Chapter { title = "WEEK 1", subtitle = "Monday, 5:40 AM", bg = "house_morning", music = "home" };
            w1.steps.Add(Story(null,
                "5:40 AM. The alarm on Mark's cracked phone buzzes under his pillow.\n\nNine people share this two-bedroom house, and somehow everyone is already awake. Mama is wringing out other people's laundry at the faucet. Tatay is lacing his boots for the construction site. Somewhere, a baby is crying."));
            w1.steps.Add(Story(Mark,
                "Classes at 8. Shift at 6 until 10. Tomorrow is the same. I'm nineteen. I can do this. I have to."));
            w1.steps.Add(Story(Lyn,
                "Kuya! My teacher says we need colored paper tomorrow. And Migo ate my baon again!"));
            w1.steps.Add(Ask(null, "You have a few minutes before you have to leave. What do you do?",
                Pick("Help Mama hang the laundry first.", Fx(energy: -5, grades: -3, family: 4),
                     "Mama smiles without saying thank you. That's how you know she means it. You arrive at class five minutes late."),
                Pick("Grab breakfast and run for the jeepney.", Fx(energy: 3),
                     "Rice and egg, eaten standing up. You make it on time, barely."),
                Pick("Skip breakfast so the little ones can have more.", Fx(energy: -6, family: 3),
                     "Your stomach grumbles through first period. Nobody at home notices. That's what you tell yourself is fine.")));
            w1.steps.Add(Story(null,
                "Payday. The envelope from the restaurant has {P}1,500 in it. Tatay's wages and Mama's laundry money go to rent and rice. Everything else falls on you.\n\nEvery peso has somewhere to go. There aren't enough pesos.").Bg("restaurant").Music("work"));
            w1.steps.Add(Budget(1500, Fare(), School(), Food(), Power(), Siblings()));
            w1.steps.Add(Evening("10:15 PM. You're home, sore from four hours on your feet. Your first quiz is on Thursday.").Bg("house_night").Music("home_night"));
            list.Add(w1);

            // ================= WEEK 2 =================
            var w2 = new Chapter { title = "WEEK 2", subtitle = "The group project", bg = "school", music = "campus" };
            w2.steps.Add(Story(Prof,
                "Your group presentation is on Friday. Meet outside class if you have to. I expect everyone to contribute equally."));
            w2.steps.Add(Story(null,
                "The group chat is full of messages. 'Library Saturday 2 PM?' You have a shift on Saturday. You haven't told them about the shift. Or the house."));
            w2.steps.Add(Ask(null, "What do you tell your groupmates?",
                Pick("Join them, and ask Boss Dom for the day off.", Fx(money: -250, grades: 6, energy: 3),
                     "Boss Dom sighs, then approves it. You lose a day's pay, but the presentation comes together, and your groupmates save you a seat."),
                Pick("Be honest: you work Saturdays. Offer to join online at night.", Fx(grades: 3, energy: -6, planning: 2),
                     "Nobody judges you. One groupmate admits she works weekends too. Asking for what you need turns out to be a skill."),
                Pick("Say nothing and let them carry it.", Fx(money: 200, grades: -6, energy: -3),
                     "You work your shift. The group finishes without you. Your name stays on the slides, and you feel it.")));
            w2.steps.Add(Story(Tatay,
                "At dinner: 'Kaya natin 'to, anak. Sipag lang. Look at me. Nobody in this house has ever slept hungry.'\n\nMama keeps her eyes on her plate. The rice is half of what it used to be.").Bg("house_night").Music("home_night"));
            w2.steps.Add(Budget(1500,
                Fare(), School(150), Food(), Power(), Siblings()));
            w2.steps.Add(Evening("Friday, 10:30 PM. The presentation went okay. Your head is pounding."));
            list.Add(w2);

            // ================= WEEK 3 =================
            var w3 = new Chapter { title = "WEEK 3", subtitle = "Bea's project", bg = "house_night", music = "home_night" };
            w3.steps.Add(Story(Bea,
                "Kuya... my class needs {P}300 for the science fair materials. It's okay if I can't join. Really. I told Mama I don't need it."));
            w3.steps.Add(Story(null,
                "Bea is fourteen and already knows when not to ask. That's what hurts. Behind her, Jun is trying to study on the floor because the only table is covered with other people's laundry."));
            w3.steps.Add(Ask(null, "What do you do?",
                Pick("Give her the {P}300 from your savings.", Fx(money: -300, family: 6),
                     "Bea hugs you so hard she almost knocks the phone out of your hand."),
                Pick("Help her build something from recycled materials.", Fx(money: -50, energy: -8, family: 8, grades: -2),
                     "At midnight you and Bea are cutting plastic bottles by flashlight. It's the most you've talked in months."),
                Pick("Tell her it will have to wait.", Fx(family: -8),
                     "Bea nods too quickly. 'Okay lang, Kuya.' It is not okay, and you both know it.")));
            w3.steps.Add(Story(null,
                "That night nine people sleep in a house built for four. Migo's foot is on your chest. Joy cries at 2 AM, and Mama rocks her until 3.\n\nYou stare at the ceiling and count. How many mouths. How many years. And what happens if something goes wrong?"));
            w3.steps.Add(Budget(1500, Fare(), School(), Food(), Power(), Siblings()));
            w3.steps.Add(Evening("Sunday night. Tomorrow starts all over again."));
            list.Add(w3);

            // ================= WEEK 4 =================
            var w4 = new Chapter { title = "WEEK 4", subtitle = "Thursday, 8:42 PM", bg = "restaurant", music = "work" };
            w4.steps.Add(Story(null,
                "Mid-shift, your phone buzzes eleven times. Mama. Eleven missed calls."));
            w4.steps.Add(Story(Mama,
                "Anak, si Joy... sobrang init niya. (She's burning up.) Hindi na siya gumigising nang maayos. (She won't wake up properly.) Tatay's pay isn't until Monday. I don't know what to do..."));
            w4.steps.Add(Story(Boss,
                "Go. Go! We'll cover your shift. Text me when she's okay."));
            w4.steps.Add(WithBg("hospital", Ask(null,
                "At the hospital, the desk asks for a {P}3,000 deposit. You have only what's in your pocket and your savings.",
                Pick("Pay what you can and ask the hospital social worker about help and PhilHealth.", Fx(money: -300, energy: -12, family: 4, planning: 4),
                     "The line is long and the chairs are hard. But the social worker explains what PhilHealth can cover and what the hospital can waive. The bill shrinks. She also asks when anyone in your house last checked the membership. Nobody remembers."),
                Pick("Borrow {P}3,000 from the '5-6' lender down the street.", Fx(energy: -6, debt: 3600),
                     "It's fast. No papers, no questions, just a number that grows every week. The deposit is paid, but the debt follows you home."),
                Pick("Ask Boss Dom for a salary advance and message your aunt.", Fx(money: -200, energy: -6, family: 2, debt: 1000),
                     "Boss Dom advances {P}1,000 with no interest, to be deducted from your next pay. Your aunt sends the rest. It's not nothing, but it's not free either."))).Music("tense"));
            w4.steps.Add(Story(null,
                "Joy's fever breaks at dawn. Pneumonia, the doctor says. She'll be okay.\n\nIn the hallway, Mama presses her forehead against the wall. Tatay arrives still in his work boots, saying nothing. Nobody says it out loud, but the thought is in the corridor with you: what if this had happened and no one could pay?").Music("quiet"));
            w4.steps.Add(Story(Mark,
                "I work. Tatay works. Mama works. We all work. So why does it feel like we're always one emergency away from falling apart?"));
            w4.steps.Add(Budget(1500,
                Fare(),
                Item("Joy's medicine and follow-up check", 400, "Joy's recovery suffers and the guilt eats at everyone.", Fx(family: -8, energy: -4)),
                Food(), Power(), Siblings()));
            list.Add(w4);

            // ================= WEEK 5 =================
            var w5 = new Chapter { title = "WEEK 5", subtitle = "Midnight at the table", bg = "kitchen_night", music = "night" };
            w5.steps.Add(Story(null,
                "Sunday, 12:30 AM. You wake up for water and find the kitchen light on. Mama and Tatay are at the table with a notebook, a calculator, and a pile of coins.\n\nThey're counting. They don't see you."));
            w5.steps.Add(Story(Tatay,
                "...kulang pa rin ng limang daan. (Still five hundred short.) I'll ask the foreman for overtime. Double shifts, if I have to."));
            w5.steps.Add(Story(Mama,
                "Ramon, your back..."));
            w5.steps.Add(Ask(Mark,
                "This is the moment. This house has been quiet about this for years. What do you say?",
                Pick("'Tay, Nay, can we talk about how we plan for the household? Not to blame anyone. I want to help.'",
                     Fx(family: 4, planning: 6),
                     "Tatay's jaw tightens. Mama puts down the pencil. Neither of them walks away. Tonight, that counts as a victory.", "calm"),
                Pick("'Why did you have so many kids if we can't afford them?'",
                     Fx(family: -12, planning: -2),
                     "The words hang in the air. Tatay stands so fast the chair scrapes. 'Wala kang karapatan!' (You have no right!) Mama looks at you. Not angry. Just tired. 'Not like that, anak.'", "blamed"),
                Pick("'Don't worry. I'll pick up more shifts. I'll pay for everything.'",
                     Fx(money: 300, energy: -15, family: 1, planning: -3),
                     "Tatay nods, relieved. Mama says nothing for a long time. 'Hindi mo trabaho 'yan, anak,' she whispers. (That isn't your job.)", "alone")));
            w5.steps.Add(Story(Tatay,
                "'I work from sunrise to dark! What more do you want from me? Working harder is the answer. It has always been the answer.'"));
            w5.steps.Add(Story(Mama,
                "'Ramon. Hindi na sapat ang sipag.' (Hard work isn't enough anymore.) 'We've done it your way for twenty years. We have six children and no plan. Our eldest works nights while we count coins. We don't just need more money. We need to learn how to plan.'"));
            w5.steps.Add(Ask(Mark,
                "Tatay is quiet. Mama is waiting for you.",
                Pick("Thank Tatay for everything he's done. Then suggest visiting the barangay health center together.",
                     Fx(family: 6, planning: 8),
                     "Tatay's shoulders drop a little. 'Sige,' he says finally, 'we'll go.' It isn't agreement yet, but it's the first door opening.", "clinic"),
                Pick("Open your expense notebook and show where every peso goes each week.",
                     Fx(family: 3, planning: 9),
                     "Tatay reads the columns slowly. 'Kahit gaano kasipag, hindi aabot,' he mutters. (No matter how hard we work, it won't reach.) He pushes the notebook back. 'Okay. Let's ask them.'", "clinic",
                     s => s.planning >= 6, "Needs Planning 6+: you've started tracking and talking about it."),
                Pick("Tell Tatay the real problem is his attitude.",
                     Fx(family: -8, planning: -2),
                     "He pushes his chair back. 'Sige. Ikaw na ang bahala.' (Fine. You handle it.) Mama has to talk him down later. It costs everyone something tonight.", "stubborn")));
            w5.steps.Add(Budget(1500, Fare(), School(), Food(), Power(), Siblings()));
            w5.steps.Add(Evening("Sunday evening. You haven't stopped thinking about the conversation."));
            list.Add(w5);

            // ================= WEEK 6 =================
            var w6 = new Chapter { title = "WEEK 6", subtitle = "The health center", bg = "health_center", music = "calm" };
            w6.steps.Add(Story(null,
                "Saturday, 8 AM. The barangay health center is a small concrete building with a hand-painted sign and a line of mothers with babies on their laps. Posters about immunization, nutrition, and planning your family cover the walls."));
            w6.steps.Add(StoryFn(null, s => s.Has("clinic")
                ? "Tatay came willingly, though he stands like a man walking into a courtroom. Mama squeezes his hand."
                : "Mama practically had to drag Tatay here. He stands with his arms crossed, saying nothing, like a man walking into a courtroom."));
            w6.steps.Add(Story(Midwife,
                "'Magandang umaga po. Everything you tell us stays private, and the decisions here belong to the two of you. We're not here to scold anyone. We're here to give you information so you can choose together.'"));
            w6.steps.Add(Story(Midwife,
                "'Family planning isn't about having fewer people you love. It's about timing. Giving each child and each parent enough health, time, and resources. Mothers who rest between pregnancies recover better. Children get more care when families can plan.'"));
            w6.steps.Add(Story(Midwife,
                "'There are several safe, modern options: natural methods like tracking fertile days, condoms, pills, injectables, implants, IUDs, and permanent methods for couples who are certain. No method is right for everyone. A health worker checks your medical history first, and you can change your mind later.'"));
            w6.steps.Add(Story(Mama,
                "'Why didn't anyone tell us this before?' she says quietly. 'We thought it was embarrassing to ask. Or that it was only for rich people.'\n\n'Many couples feel the same,' says Midwife Grace. 'That's exactly why we do this.'"));
            w6.steps.Add(StoryFn(Tatay, s => s.Has("clinic")
                ? "'And the kids? If we're here... can the little ones be checked too?'\n\n'Of course. Joy's vaccines and Migo's weight, today,' says Midwife Grace. Tatay looks at the floor. 'Sige. Let's listen.'"
                : "He is still stiff. Still guarded. But when Midwife Grace says 'mothers need rest between births, and so do fathers,' something in his face loosens, just a little."));
            w6.steps.Add(Ask(Mark,
                "Your parents are talking with Midwife Grace about their options. This part is theirs to decide. How do you support them?",
                Pick("Give them privacy. Ask the nurse about the kids' vaccines and vitamins.", Fx(family: 6, planning: 5, energy: -2),
                     "You wait outside with Migo on your lap. Joy's records get updated. When your parents come out, Mama squeezes your arm. 'Salamat, anak.'"),
                Pick("Offer to go with Mama to follow-up visits, if she wants company.", Fx(family: 6, planning: 4, energy: -4),
                     "'Maybe,' Mama says, smiling. 'Not for everything. But yes, sometimes.' The offer matters more than the answer."),
                Pick("Tell your parents which method YOU think they should choose.", Fx(family: -8, planning: -2),
                     "'Mark.' Mama's voice is gentle but firm. 'This is our decision. Thank you for caring, but let us choose together.' You step back, embarrassed. She's right.")));
            w6.steps.Add(Story(null,
                "On the walk home, Mama holds a leaflet and a follow-up schedule. Tatay carries Joy on his shoulders. Nobody says much, but the silence is different now. It has room in it."));
            w6.steps.Add(Budget(1500,
                Fare(), Food(), Power(),
                Item("Family budget notebook and weekly meeting", 50, "no tracking, no plan. The habit doesn't start.", Fx(), false, Fx(planning: 3)),
                Siblings()));
            list.Add(w6);

            // ================= WEEK 7 =================
            var w7 = new Chapter { title = "WEEK 7", subtitle = "A family meeting", bg = "family_table", music = "hopeful" };
            w7.steps.Add(Story(null,
                "Three weeks later. Sunday afternoon. Everyone is crowded around the one table: Tatay, Mama, Mark, Jun, Bea, even Lyn, who insists on holding the pencil."));
            w7.steps.Add(Story(Mama,
                "'We're going to do this properly. Needs first: rice, rent, electricity, school, medicine. Then savings. Then wants. And everyone gets a say.'"));
            w7.steps.Add(Story(Tatay,
                "'I'll ask for fewer overtime shifts. The foreman says my back needs rest anyway. Mama's laundry, I'll help carry. And Mark...' He clears his throat. 'You have been carrying too much.'"));
            w7.steps.Add(Story(Jun,
                "'I can watch Migo and Joy after school so you can study, Kuya. And Bea can help Lyn with homework.'"));
            w7.steps.Add(Ask(Mark,
                "The family is ready to share the load. How do you change your own routine?",
                Pick("Cut one shift a week to protect your studies and sleep.", Fx(money: -300, energy: 12, grades: 8, family: 4, planning: 3),
                     "Less pay, more sleep. For the first time in months, you start a lecture awake."),
                Pick("Keep your shifts, but let Jun and Bea share the household chores.", Fx(energy: 4, family: 5, planning: 4),
                     "Bea sorts laundry with a dramatic sigh. Jun learns to cook rice properly. The house runs a little smoother."),
                Pick("Keep doing everything as before. You don't want to burden anyone.", Fx(energy: -8, family: -4, planning: -2),
                     "'Kuya,' Bea says, 'we want to help.' You nod, but the old habit stays. It's hard to let others carry weight you've carried for years.")));
            w7.steps.Add(Budget(1500,
                Fare(), School(),
                Food(), Power(),
                Item("Health center follow-up and vitamins", 150, "missed check-ups. Small problems can become big ones.", Fx(family: -3), false, Fx(planning: 3))));
            list.Add(w7);

            return list;
        }

        // ---------- end of week passive checks (used by the controller) ----------
        public static string WeekEnd(GameState s, out Effects fx)
        {
            fx = new Effects();
            var lines = new List<string>();
            if (s.energy <= 20)
            {
                fx = fx.Plus(Fx(grades: -5, family: -2));
                lines.Add("You were running on fumes. You fell asleep during a lecture, and snapped at Lyn when she asked for help with homework.");
            }
            else if (s.energy >= 70)
            {
                lines.Add("You feel steady this week. Tired, but not empty.");
            }
            if (s.grades <= 35)
                lines.Add("Prof. Reyes asks to see you after class. 'Mark, I know you're working. But I can't help if you disappear.'");
            if (s.family <= 30)
                lines.Add("Dinner is quiet. Not the peaceful kind.");
            if (s.debt > 0)
                lines.Add("You still owe {P}" + s.debt.ToString("N0") + ". It follows you into every budget.");
            if (lines.Count == 0)
                lines.Add("A quiet week closes. Not easy, but you're still standing.");
            return string.Join("\n\n", lines.ToArray());
        }

        // ---------- endings ----------
        public static void Ending(GameState s, out string title, out string body)
        {
            string debtLine = s.debt >= 1000
                ? "\n\nThe loan still hangs over them, a reminder of the week they had no safety net."
                : "";

            if (s.planning >= 24 && s.family >= 50 && s.grades >= 40 && s.energy >= 20)
            {
                title = "A PLAN, TOGETHER";
                body = "Months later, the house is still small. Nine people still share two rooms. But the table has a notebook on it now, and everyone has a say.\n\nMama's laundry service has grown to five households, with Jun and Bea helping on weekends. Tatay works fewer overtime shifts and goes to the health center with Mama for their check-ups. Joy's vaccines are complete. Bea's science project won a ribbon.\n\nMark still works three nights a week, but he sleeps, and his grades are climbing. He realizes the future he wanted was never one he had to build alone. It was one the family could plan together." + debtLine;
            }
            else if (s.grades < 30 || s.energy < 15)
            {
                title = "RUNNING ON EMPTY";
                body = "In March, Mark takes a leave of absence. Not because he failed, but because he has nothing left.\n\nHis parents are learning to plan, but it came late, after the exhaustion had already set in. 'We should have learned this before you had to carry it,' Mama tells him.\n\nMark rests. He sleeps. He watches Jun and Bea take on more at home. Next semester, he'll go back. This time he won't be doing it alone." + debtLine;
            }
            else if (s.family < 35)
            {
                title = "WALLS BETWEEN US";
                body = "The house is quiet in the wrong way. Tatay doesn't ask about school. Mama sets out dinner and leaves the room. Mark works, studies, and sleeps at a friend's place on weekends.\n\nNothing dramatic happened. Words were said, and nobody took them back. Mark finally understands that planning a family's future starts with the conversation. And that conversation has to begin with respect.\n\nThere is still time. Tomorrow he'll sit at the table and say, 'Tay, Nay, can we talk?'" + debtLine;
            }
            else if (s.planning >= 12)
            {
                title = "FIRST STEPS";
                body = "Not everything is fixed. Rent is still tight, and money still runs short at the end of the month. But something has changed.\n\nMama and Tatay have a follow-up appointment at the health center. The family has a notebook, even if it's messy. Mark has stopped thinking that 'being the eldest' means 'being the only one.'\n\nIt isn't a happy ending yet. It's a start, and in Mark's house, that is a very big thing." + debtLine;
            }
            else
            {
                title = "CARRYING IT ALONE";
                body = "Mark keeps working. He keeps studying. He keeps paying for the things that never end. His grades survive. So does the family.\n\nBut nothing changes. The same worries sit at the same table. Mama still counts coins at midnight. Tatay still says 'sipag lang.' Mark is proud and exhausted in equal measure.\n\nOn the jeepney to work, he thinks about what Mama said that night: 'We need to learn how to plan.' Maybe next time he'll listen." + debtLine;
            }
        }

        public static string EndingMusic(string endingTitle)
        {
            if (endingTitle == "A PLAN, TOGETHER") return "ending_good";
            if (endingTitle == "FIRST STEPS" || endingTitle == "CARRYING IT ALONE") return "ending_neutral";
            return "ending_sad";
        }

        public const string Takeaways =
            "<b>What this story is about</b>\n\n" +
            "• <b>Family planning is a couple's informed choice.</b> Barangay health centers and Rural Health Units offer counseling, and a health worker can help you find what suits you.\n" +
            "• <b>Talk early, and without blame.</b> 'How can we plan together?' opens doors that 'Why did you...?' closes.\n" +
            "• <b>Needs first, then savings, then wants.</b> Write the numbers down. A notebook is a plan.\n" +
            "• <b>Build a cushion.</b> Learn about PhilHealth before an emergency. Avoid '5-6' loans.\n" +
            "• <b>The eldest shouldn't carry everything.</b> Share the load. Everyone in the family has a part.\n\n" +
            "<size=22><i>This is a work of fiction. For advice about your own family, visit your local health center or Rural Health Unit.</i></size>";
    }
}
