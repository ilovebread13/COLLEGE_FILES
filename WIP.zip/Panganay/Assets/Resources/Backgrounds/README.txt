Full-screen backgrounds, 16:9 (e.g. 1920x1080), PNG or JPG. Names:

  title.png            title screen
  house_morning.png    Week 1 opening (the crowded house, 5:40 AM)
  house_night.png      evenings at home (weeks 1, 2, 3)
  restaurant.png       Mark's workplace (fast-food shift)
  school.png           campus / classroom (week 2)
  hospital.png         week 4 emergency
  kitchen_night.png    week 5, midnight at the table
  health_center.png    week 6, barangay health center
  family_table.png     week 7, family meeting
  ending.png           ending screens

Any missing file falls back to a plain dark background.
To use different backgrounds, edit the .Bg("name") calls / chapter bg in Content.cs.
