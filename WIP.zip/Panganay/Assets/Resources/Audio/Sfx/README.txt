Sound effects. Drop .wav / .ogg / .mp3 files here to REPLACE the simple built-in tones.
The file name (without extension) must match:

  click      any button press
  blip       typewriter sound while a character speaks (very short, ~30 ms; played every 3rd letter)
  gain       a stat goes up / good outcome
  loss       a stat goes down / bad outcome
  chapter    start of a new week and the ending
  save       game saved

If a file is missing, the built-in tone is used, so the game always has sound.
