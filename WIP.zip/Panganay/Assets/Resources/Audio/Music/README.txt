Background music. Drop .mp3 / .ogg / .wav files here. They loop and crossfade automatically.
The file name (without extension) must match the cue name:

  title            title screen
  home             Week 1 morning, the crowded house
  campus           Week 2, school
  home_night       evenings at home (weeks 1, 2, 3)
  work             the restaurant, payday
  tense            Week 4, the hospital emergency
  quiet            Week 4, after Joy's fever breaks
  night            Week 5, midnight at the kitchen table
  calm             Week 6, the health center
  hopeful          Week 7, the family meeting
  ending_good      "A Plan, Together"
  ending_neutral   "First Steps" and "Carrying It Alone"
  ending_sad       "Running on Empty" and "Walls Between Us"

A missing file means silence for that scene (the old music fades out).
To change which scene uses which track, edit the music = "..." and .Music("...") values in Content.cs.
Tip: use royalty-free or CC0 music, and credit the artist if the license requires it.
