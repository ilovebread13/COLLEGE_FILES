Standing character art (visual novel sprites). PNG with a transparent background.
Tall/portrait images work best (e.g. 800x1400). They are scaled to fit, keeping aspect ratio.
The file name must match the speaker name exactly:

  Mark.png            (always shown on the LEFT)
  Mama Liza.png       (other characters appear on the RIGHT when they speak)
  Tatay Ramon.png
  Bea.png
  Jun.png
  Lyn.png
  Midwife Grace.png
  Boss Dom.png
  Prof. Reyes.png

The character who is speaking is shown bright, the other one dimmed.
Any missing file shows a colored placeholder silhouette with the name.
